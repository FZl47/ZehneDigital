from django.contrib import admin
from .models import *

admin.site.register(ZehneDigitalInfo)
admin.site.register(Administrator)
admin.site.register(Support_Ticket)

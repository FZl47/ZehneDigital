from django.db import models
from ZehneDigital.Tools import TimeIran, GetDifferenceTime


class Support_Ticket(models.Model):
    Title = models.CharField(max_length=700)
    Name = models.CharField(max_length=250)
    Email = models.CharField(max_length=300)
    Text = models.TextField()
    DateSubmit = models.DateTimeField(null=True,blank=True)
    IsRead = models.BooleanField(default=False)

    def __str__(self):
        return self.Title

    def TimePast(self):
        return GetDifferenceTime(self.DateSubmit)

class Administrator(models.Model):
    Name = models.CharField(max_length=300)
    Family = models.CharField(max_length=350)
    UserName = models.CharField(max_length=1000)
    Password = models.CharField(max_length=1000)
    TimeOnline = models.DateTimeField(null=True,blank=True)
    TimeLastAction = models.DateTimeField(null=True,blank=True)
    AccessLevel = models.IntegerField(default=3)

    def __str__(self):
        return f'{self.Name} {self.Family}'

    def SetLastActionTime(self):
        self.TimeLastAction = TimeIran
        self.save()
        
    def SetLastOnline(self):
        self.TimeOnline = TimeIran
        self.save()


class ZehneDigitalInfo(models.Model):
    Title = models.CharField(max_length=300)
    AboutUs = models.TextField()
    Email = models.CharField(max_length=300)
    PhoneNumber = models.CharField(max_length=50)

    def __str__(self):
        return self.Title


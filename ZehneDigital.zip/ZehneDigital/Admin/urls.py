from django.urls import path
from .views import *

app_name = 'Admin'
urlpatterns = [
    path('',PanelAdmin),
    path('RemoveComment',RemoveComment),
    path('SubmitInfoComment',SubmitInfoComment),
    path('GetArticle',GetArticle),
    path('Obj/<Object>/<ID>',PanelAdmin_ChangeObject),
    path('Obj/Save',PanelAdmin_ChangeObject_Save),
    path('Obj/RemoveController',PanelAdmin_ChangeObject_RemoveController),
    path('Login',Login),
    path('Login/Check',LoginCheck),
]
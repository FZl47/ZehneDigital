import json, ast

from django.core import serializers
from django.db.models import Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from Article.models import *
from Admin.models import *
from ZehneDigital.Security import *
from ZehneDigital.Tools import *


def CheckBooleanStr(Str):
    if Str == 'true' or Str == True:
        return True
    elif Str == 'false' or Str == False:
        return False


def GetObjectTextBoxID(Model, TextBoxID):
    Obj = Model.objects.filter(TextBoxID=TextBoxID).first()
    return Obj


def PanelAdmin_ChangeObject(request, Object, ID):
    UserName = request.COOKIES.get('qazRWxN')
    Password = request.COOKIES.get('sZTyJLp')
    if UserName != None and Password != None:
        UserName = UnDecode(UserName)
        Password = UnDecode(Password)
        StateAdmin = Administrator.objects.filter(UserName=UserName, Password=Password).first()
        if StateAdmin == None:
            return redirect('/AdminPanel/Login')
    else:
        return redirect('/AdminPanel/Login')
    Context = {}
    try:
        Object = eval(Object)
    except:
        return redirect('/Err/404')
    StateObj = ''
    try:
        StateObj = Object.objects.filter(id=ID).first()
    except:
        StateObj = None
    if StateObj == None:
        return redirect('/Err/404')
    StateObjDesign = ArticleDesign.objects.filter(Article_id=StateObj.id).first()
    ListControllerResult = []

    if StateObjDesign is not None:
        StateObjDesign: ArticleDesign

        ListCreateController = ast.literal_eval(StateObjDesign.ListCreatedController)
        for Item in ListCreateController:

            try:
                Item = json.loads(Item)
            except:
                pass
            ObjectSearch = Item['TypeController']
            TextBoxID = Item['TextBoxID']
            if ObjectSearch == 'Title':
                ObjectGeted = ArticleDesign_Title.objects.filter(TextBoxID=TextBoxID).first()
                ListControllerResult.append(ObjectGeted)
                ObjectGeted: ArticleDesign_Title

            elif ObjectSearch == 'Text':
                ObjectGeted = ArticleDesign_Text.objects.filter(TextBoxID=TextBoxID).first()
                ListControllerResult.append(ObjectGeted)


            elif ObjectSearch == 'Image':
                ObjectGeted = ArticleDesign_Image.objects.filter(TextBoxID=TextBoxID).first()
                ListControllerResult.append(ObjectGeted)


            elif ObjectSearch == 'Link':
                ObjectGeted = ArticleDesign_Link.objects.filter(TextBoxID=TextBoxID).first()
                ListControllerResult.append(ObjectGeted)

    Context['Obj'] = StateObj
    Context['Obj_Design'] = StateObjDesign
    Context['Controllers'] = ListControllerResult
    StateAdmin.SetLastOnline()
    return render(request, 'ViewObject.html', Context)


def PanelAdmin_ChangeObject_Save(request):
    UserName = request.COOKIES.get('qazRWxN')
    Password = request.COOKIES.get('sZTyJLp')
    if UserName != None and Password != None:
        UserName = UnDecode(UserName)
        Password = UnDecode(Password)
        StateAdmin = Administrator.objects.filter(UserName=UserName, Password=Password).first()
        if StateAdmin == None:
            return redirect('/AdminPanel/Login')
    else:
        return redirect('/AdminPanel/Login')
    Data = dict(request.POST)
    Node = ''
    try:
        Node = Data['NodeText'][0]
    except:
        return redirect('/Err/404')
    Node_Edit = json.loads(Data['NodeEdit'][0])

    IDArticle = int(Data['IDArticle'][0])
    StateArticle = Article.objects.get(id=IDArticle)
    if StateArticle is None:
        return redirect('/Err/404')
    StateArticleDesign = ArticleDesign.objects.filter(Article_id=StateArticle.id).first()
    IDArticleDesign = 0
    if StateArticleDesign == None:
        StateArticleDesign = ArticleDesign.objects.create(Node=Node, Article_id=IDArticle,
                                                          ListCreatedController=Node_Edit['ListCreated'])
        IDArticleDesign = StateArticleDesign.id
    else:
        IDArticleDesign = StateArticleDesign.id
        StateArticleDesign.Node = Node
        StateArticleDesign.Article_id = IDArticle
        StateArticleDesign.ListCreatedController = Node_Edit['ListCreated']
        StateArticleDesign.save()

    Titles = Node_Edit['Titles']
    Texts = Node_Edit['Texts']
    Links = Node_Edit['Links']
    Images = Node_Edit['Images']

    StatusTitles = 'NoDetect'
    StatusTexts = 'NoDetect'
    StatusLinks = 'NoDetect'
    StatusImages = 'NoDetect'

    for Title in Titles:
        TextBoxID = Title['TextBoxID']
        Text = Title['Text']
        Bold = CheckBooleanStr(Title['Bold'])
        Italic = CheckBooleanStr(Title['Italic'])
        FontSize = Title['FontSize']
        Mt = Title['Mt']
        Mb = Title['Mb']
        Mr = Title['Mr']
        Ml = Title['Ml']
        Top = Title['Top']
        Right = Title['Right']
        Color = Title['Color']
        Width = Title['Width']
        Height = Title['Height']
        Center = CheckBooleanStr(Title['Center'])
        TextAlign = CheckBooleanStr(Title['TextAlign'])
        Position = CheckBooleanStr(Title['Position'])
        Object = GetObjectTextBoxID(ArticleDesign_Title, TextBoxID)
        if Object is None:
            Object = ArticleDesign_Title.objects.create(ArticleDesign_id=IDArticleDesign, TextBoxID=TextBoxID,
                                                        Text=Text, Bold=Bold,
                                                        Italic=Italic, FontSize=FontSize, Mt=Mt, Mb=Mb, Mr=Mr, Ml=Ml
                                                        , Color=Color, M_Auto=Center, TextCenter=TextAlign
                                                        , Position=Position, Top=Top, Right=Right, Width=Width,
                                                        Height=Height)
        else:

            Object.Text = Text
            Object.Bold = Bold
            Object.Italic = Italic
            Object.FontSize = FontSize
            Object.Mt = Mt
            Object.Mb = Mb
            Object.Mr = Mr
            Object.Ml = Ml
            Object.Color = Color
            Object.M_Auto = Center
            Object.TextCenter = TextAlign
            Object.Position = Position
            Object.Top = Top
            Object.Right = Right
            Object.Width = Width
            Object.Height = Height
            Object.save()
    StatusTitles = '200'

    for Text in Texts:
        TextBoxID = Text['TextBoxID']
        TextEdit = Text['Text']
        Bold = CheckBooleanStr(Text['Bold'])
        Italic = CheckBooleanStr(Text['Italic'])
        FontSize = Text['FontSize']
        Mt = Text['Mt']
        Mb = Text['Mb']
        Mr = Text['Mr']
        Ml = Text['Ml']
        Top = Text['Top']
        Right = Text['Right']
        Color = Text['Color']
        Width = Text['Width']
        Height = Text['Height']
        Center = CheckBooleanStr(Text['Center'])
        TextAlign = CheckBooleanStr(Text['TextAlign'])
        Position = CheckBooleanStr(Text['Position'])
        Object = GetObjectTextBoxID(ArticleDesign_Text, TextBoxID)
        if Object is None:
            Object = ArticleDesign_Text.objects.create(ArticleDesign_id=IDArticleDesign, TextBoxID=TextBoxID,
                                                       Text=TextEdit, Bold=Bold,
                                                       Italic=Italic, FontSize=FontSize, Mt=Mt, Mb=Mb, Mr=Mr, Ml=Ml
                                                       , Color=Color, M_Auto=Center, TextCenter=TextAlign
                                                       , Position=Position, Top=Top, Right=Right, Width=Width,
                                                       Height=Height)
        else:

            Object.Text = TextEdit
            Object.Bold = Bold
            Object.Italic = Italic
            Object.FontSize = FontSize
            Object.Mt = Mt
            Object.Mb = Mb
            Object.Mr = Mr
            Object.Ml = Ml
            Object.Color = Color
            Object.M_Auto = Center
            Object.TextCenter = TextAlign
            Object.Position = Position
            Object.Top = Top
            Object.Right = Right
            Object.Width = Width
            Object.Height = Height
            Object.save()

    StatusTexts = '200'

    for Link in Links:
        TextBoxID = Link['TextBoxID']
        Text = Link['Text']
        Bold = CheckBooleanStr(Link['Bold'])
        Italic = CheckBooleanStr(Link['Italic'])
        FontSize = Link['FontSize']
        Mt = Link['Mt']
        Mb = Link['Mb']
        Mr = Link['Mr']
        Ml = Link['Ml']
        Top = Link['Top']
        Right = Link['Right']
        Color = Link['Color']
        Href = Link['Href']
        Width = Link['Width']
        Height = Link['Height']
        Center = CheckBooleanStr(Link['Center'])
        TextAlign = CheckBooleanStr(Link['TextAlign'])
        Position = CheckBooleanStr(Link['Position'])
        Object = GetObjectTextBoxID(ArticleDesign_Link, TextBoxID)
        if Object is None:
            Object = ArticleDesign_Link.objects.create(ArticleDesign_id=IDArticleDesign, TextBoxID=TextBoxID, Text=Text,
                                                       Bold=Bold,
                                                       Italic=Italic, FontSize=FontSize, Mt=Mt, Mb=Mb, Mr=Mr, Ml=Ml
                                                       , Color=Color, M_Auto=Center, TextCenter=TextAlign
                                                       , Position=Position, Href=Href, Top=Top, Right=Right,
                                                       Width=Width, Height=Height)
        else:

            Object.Text = Text
            Object.Bold = Bold
            Object.Italic = Italic
            Object.FontSize = FontSize
            Object.Mt = Mt
            Object.Mb = Mb
            Object.Mr = Mr
            Object.Ml = Ml
            Object.Color = Color
            Object.M_Auto = Center
            Object.TextCenter = TextAlign
            Object.Position = Position
            Object.Href = Href
            Object.Top = Top
            Object.Right = Right
            Object.Width = Width
            Object.Height = Height
            Object.save()
    StatusLinks = '200'

    CounterLoopImages = 0

    for Image in Images:
        CounterLoopImages += 1
        TextBoxID = Image['TextBoxID']
        Mt = Image['Mt']
        Mb = Image['Mb']
        Mr = Image['Mr']
        Ml = Image['Ml']
        Top = Image['Top']
        Right = Image['Right']
        Width = Image['Width']
        Height = Image['Height']
        Center = CheckBooleanStr(Image['Center'])
        TextAlign = CheckBooleanStr(Image['TextAlign'])
        Position = CheckBooleanStr(Image['Position'])
        Object = GetObjectTextBoxID(ArticleDesign_Image, TextBoxID)
        ImageFile = request.FILES.get(f'Image_{CounterLoopImages}')
        if Object is None:
            Object = ArticleDesign_Image.objects.create(ArticleDesign_id=IDArticleDesign, TextBoxID=TextBoxID
                                                        , Image=ImageFile, Mt=Mt, Mb=Mb, Mr=Mr, Ml=Ml,
                                                        M_Auto=Center,
                                                        TextCenter=TextAlign, Position=Position, Top=Top,
                                                        Right=Right, Width=Width, Height=Height)
        else:

            # Object.Image = ImageFile
            Object.Mt = Mt
            Object.Mb = Mb
            Object.Mr = Mr
            Object.Ml = Ml
            Object.M_Auto = Center
            Object.TextCenter = TextAlign
            Object.Position = Position
            Object.Top = Top
            Object.Right = Right
            Object.Width = Width
            Object.Height = Height
            Object.save()

        StatusImages = '200'

    # for I in range(1,ImageLength+1):
    #     Image = request.FILES.get(f'Image_{I}')
    StateAdmin.SetLastActionTime()

    return render(request, 'ObjectSave.html')


@csrf_exempt
def PanelAdmin_ChangeObject_RemoveController(request):
    if request.is_ajax() and request.POST:
        Context = {}
        Data = json.loads(request.body)
        TextBoxID = Data.get('TextBox')
        Type = Data.get('Type')
        ObjectSearch = ''
        if Type == 'Title':
            ObjectSearch = ArticleDesign_Title
        if Type == 'Text':
            ObjectSearch = ArticleDesign_Text
        if Type == 'Link':
            ObjectSearch = ArticleDesign_Link
        if Type == 'Image':
            ObjectSearch = ArticleDesign_Image

        ObjectGet = ObjectSearch.objects.filter(TextBoxID=TextBoxID).first()
        if ObjectGet is not None:
            ObjectGet.delete()
            Context['Status'] = '200'
        return JsonResponse(Context)
    return redirect('/Err/403')


def PanelAdmin(request):
    Context = {}
    UserName = request.COOKIES.get('qazRWxN')
    Password = request.COOKIES.get('sZTyJLp')
    if UserName != None and Password != None:
        UserName = UnDecode(UserName)
        Password = UnDecode(Password)
        StateAdmin = Administrator.objects.filter(UserName=UserName, Password=Password).first()
        if StateAdmin != None:
            ListArticleWithoutDesign = []
            for i in Article.objects.all():
                StateArticleDesign = ArticleDesign.objects.filter(Article_id=i.id).first()
                if StateArticleDesign is None:
                    ListArticleWithoutDesign.append(i)
            Context['ArticleWithoutDesign'] = ListArticleWithoutDesign[::-1]
            Context['CommentsMostCheck'] = Comment.objects.filter(Is_Check=False)[::-1]
            Context['SupportMessages'] = Support_Ticket.objects.all()[::-1]
            Context['Categories'] = CategoriesArticle.objects.all()
        else:
            return redirect('/AdminPanel/Login')
    else:
        return redirect('/AdminPanel/Login')
    StateAdmin.SetLastOnline()
    return render(request, 'PanelAdmin.html', Context)



@csrf_exempt
def GetArticle(request):
    UserName = request.COOKIES.get('qazRWxN')
    Password = request.COOKIES.get('sZTyJLp')
    if request.is_ajax():
        if UserName != None and Password != None:
            UserName = UnDecode(UserName)
            Password = UnDecode(Password)
            StateAdmin = Administrator.objects.filter(UserName=UserName, Password=Password).first()
            if StateAdmin != None:
                Context = {}
                Data = json.loads(request.body)
                Type = Data.get('TypeGet')
                if Type == 'Category':
                    CategoryID = Data.get('CategoryID')
                    if CategoryID is not None:
                        StateCategory = CategoriesArticle.objects.filter(id=CategoryID).first()
                        if StateCategory is not None:
                            Context['Articles'] = StateCategory.Get_All_Articles()
                            Context['Status'] = '200'
                elif Type == 'Search':
                    TextSearch = Data.get('TextSearch') or ''
                    LookUp = Q(Title__icontains=TextSearch)
                    StateArticles = Article.objects.filter(LookUp)
                    Context['Articles'] = StateArticles
                    Context['Status'] = '200'
                ListArticles = []
                for i in Context['Articles']:
                    Dict = {
                        'id':i.id,
                        'Title':i.Title,
                        'DateCreate':i.TimePast(),
                        'IsShow':i.IsShow
                    }
                    ListArticles.append(Dict)
                Context['Articles'] = ListArticles
                return JsonResponse(Context)
    return redirect('/Err/403')






@csrf_exempt
def SubmitInfoComment(request):
    UserName = request.COOKIES.get('qazRWxN')
    Password = request.COOKIES.get('sZTyJLp')
    if request.is_ajax():
        if UserName != None and Password != None:
            UserName = UnDecode(UserName)
            Password = UnDecode(Password)
            StateAdmin = Administrator.objects.filter(UserName=UserName, Password=Password).first()
            if StateAdmin != None:
                Context = {}
                Data = json.loads(request.body)
                try:
                    ID = Data.get('ID') or ''
                    Checked = Data.get('Checked')
                    Active = Data.get('Active')
                    StateComment = Comment.objects.filter(id=ID).first()
                    if StateComment != None:
                        StateComment.Is_Check = Checked
                        StateComment.Is_Active = Active
                        StateComment.save()
                        Context['Status'] = '200'
                    else:
                        Context['Status'] = '404'
                except:
                    Context['Status'] = '500'
                return JsonResponse(Context)
    return redirect('/Err/403')








@csrf_exempt
def RemoveComment(request):
    UserName = request.COOKIES.get('qazRWxN')
    Password = request.COOKIES.get('sZTyJLp')
    if request.is_ajax():
        if UserName != None and Password != None:
            UserName = UnDecode(UserName)
            Password = UnDecode(Password)
            StateAdmin = Administrator.objects.filter(UserName=UserName, Password=Password).first()
            if StateAdmin != None:
                Context = {}
                Data = json.loads(request.body)
                try:
                    ID = Data.get('ID') or ''
                    StateComment = Comment.objects.filter(id=ID).first()
                    if StateComment != None:
                        StateComment.delete()
                        Context['Status'] = '200'
                    else:
                        Context['Status'] = '404'
                except:
                    Context['Status'] = '500'
                return JsonResponse(Context)
    return redirect('/Err/403')


def Login(request):
    UserName = request.COOKIES.get('qazRWxN')
    Password = request.COOKIES.get('sZTyJLp')
    if UserName != None and Password != None:
        UserName = UnDecode(UserName)
        Password = UnDecode(Password)
        StateAdmin = Administrator.objects.filter(UserName=UserName, Password=Password).first()
        if StateAdmin != None:
            return redirect('/AdminPanel')

    return render(request, 'Login.html')


@csrf_exempt
def LoginCheck(request):
    if request.is_ajax():
        Context = {}
        Data = json.loads(request.body)
        UserName = ''
        Password = ''
        StatusGet = False
        try:
            UserName = Data.get('UserName') or ''
            Password = Data.get('Password') or ''
            StatusGet = True
        except:
            pass
        if StatusGet:
            StateAdmin = Administrator.objects.filter(UserName=UserName, Password=Password).first()
            if StateAdmin is not None:
                UserNameDecoded = Decode(UserName)
                PasswordDecoded = Decode(Password)
                Context['qazRWxN'] = UserNameDecoded
                Context['sZTyJLp'] = PasswordDecoded
                Context['Status'] = '200'
            else:
                Context['Status'] = '404'
        return JsonResponse(Context)
    return redirect('/Err/403')

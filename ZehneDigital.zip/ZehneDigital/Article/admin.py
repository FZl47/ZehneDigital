from django.contrib import admin
from .models import *

admin.site.register(Article)
admin.site.register(CategoriesArticle)
admin.site.register(ArticleDesign)
admin.site.register(ArticleDesign_Title)
admin.site.register(ArticleDesign_Text)
admin.site.register(ArticleDesign_Image)
admin.site.register(ArticleDesign_Link)
admin.site.register(Comment)

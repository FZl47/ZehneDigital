import math
from ZehneDigital.Tools import *
from django.db import models


class Comment(models.Model):
    Article = models.ForeignKey('Article.Article',on_delete=models.CASCADE)
    Name = models.CharField(max_length=200)
    Email = models.CharField(max_length=200)
    Text = models.TextField()
    Is_Active = models.BooleanField(default=True)
    Is_Check = models.BooleanField(default=False)
    DateTimeSubmit = models.DateTimeField()
    ReplayedName = models.CharField(max_length=200,null=True,blank=True)
    CommentIsReplayed = models.BooleanField(default=False)

    def __str__(self):
        return self.Name

    def TimePast(self):
        return GetDifferenceTime(self.DateTimeSubmit)

    def TextLess(self):
        return self.Text[:40]




class ArticleDesign(models.Model):
    Node = models.TextField()
    ListCreatedController = models.TextField()
    Article = models.ForeignKey('Article.Article', on_delete=models.CASCADE)
    def __str__(self):
        return str(self.Article.Title)


class ArticleDesign_Title(models.Model):
    ArticleDesign = models.ForeignKey('Article.ArticleDesign', on_delete=models.CASCADE)
    TypeController = models.CharField(max_length=30,default='Title')
    TextBoxID = models.CharField(max_length=30,null=True,blank=True)
    Text = models.TextField(null=True,blank=True)
    Bold = models.BooleanField(null=True,blank=True)
    Italic = models.BooleanField(null=True,blank=True)
    FontSize = models.CharField(max_length=100,null=True,blank=True)
    Mt = models.CharField(max_length=100,null=True,blank=True)
    Mr = models.CharField(max_length=100,null=True,blank=True)
    Mb = models.CharField(max_length=100,null=True,blank=True)
    Ml = models.CharField(max_length=100,null=True,blank=True)
    Color = models.CharField(max_length=20,null=True,blank=True)
    M_Auto = models.BooleanField(null=True,blank=True)
    TextCenter = models.BooleanField(null=True,blank=True)
    Position = models.BooleanField(null=True,blank=True)
    Top = models.CharField(null=True,blank=True,max_length=30)
    Right = models.CharField(null=True,blank=True,max_length=30)
    Width = models.CharField(null=True,blank=True,max_length=30)
    Height = models.CharField(null=True,blank=True,max_length=30)

    def __str__(self):
        return str(self.TextBoxID)


class ArticleDesign_Text(models.Model):
    ArticleDesign = models.ForeignKey('Article.ArticleDesign', on_delete=models.CASCADE)
    TypeController = models.CharField(max_length=30, default='Text')
    TextBoxID = models.CharField(max_length=30,null=True,blank=True)
    Text = models.TextField(null=True,blank=True)
    Bold = models.BooleanField(null=True,blank=True)
    Italic = models.BooleanField(null=True,blank=True)
    FontSize = models.CharField(max_length=100,null=True,blank=True)
    Mt = models.CharField(max_length=100,null=True,blank=True)
    Mr = models.CharField(max_length=100,null=True,blank=True)
    Mb = models.CharField(max_length=100,null=True,blank=True)
    Ml = models.CharField(max_length=100,null=True,blank=True)
    Color = models.CharField(max_length=20,null=True,blank=True)
    M_Auto = models.BooleanField(null=True,blank=True)
    TextCenter = models.BooleanField(null=True,blank=True)
    Position = models.BooleanField(null=True,blank=True)
    Top = models.CharField(null=True, blank=True, max_length=30)
    Right = models.CharField(null=True, blank=True, max_length=30)
    Width = models.CharField(null=True, blank=True, max_length=30)
    Height = models.CharField(null=True, blank=True, max_length=30)

    def __str__(self):
        return str(self.TextBoxID)


def UploadImageArticle(instance, path):
    Type = path.split('.')[1]
    return f'ArticleImages/{instance.ArticleDesign.Article.Category.id}/{instance.ArticleDesign.Article.id}.{Type}'


class ArticleDesign_Image(models.Model):
    ArticleDesign = models.ForeignKey('Article.ArticleDesign', on_delete=models.CASCADE)
    TypeController = models.CharField(max_length=30, default='Image')
    TextBoxID = models.CharField(max_length=30,null=True,blank=True)
    Image = models.ImageField(upload_to=UploadImageArticle,null=True,blank=True)
    Mt = models.CharField(max_length=100,null=True,blank=True)
    Mr = models.CharField(max_length=100,null=True,blank=True)
    Mb = models.CharField(max_length=100,null=True,blank=True)
    Ml = models.CharField(max_length=100,null=True,blank=True)
    M_Auto = models.BooleanField(null=True,blank=True)
    TextCenter = models.BooleanField(null=True,blank=True)
    Position = models.BooleanField(null=True, blank=True)
    Top = models.CharField(null=True, blank=True, max_length=30)
    Right = models.CharField(null=True, blank=True, max_length=30)
    Width = models.CharField(null=True, blank=True, max_length=30)
    Height = models.CharField(null=True, blank=True, max_length=30)

    def __str__(self):
        return str(self.TextBoxID)


class ArticleDesign_Link(models.Model):
    ArticleDesign = models.ForeignKey('Article.ArticleDesign', on_delete=models.CASCADE)
    TypeController = models.CharField(max_length=30, default='Link')
    TextBoxID = models.CharField(max_length=30,null=True,blank=True)
    Text = models.TextField(null=True,blank=True)
    Href = models.CharField(max_length=300,null=True,blank=True)
    Bold = models.BooleanField(null=True,blank=True)
    Italic = models.BooleanField(null=True,blank=True)
    FontSize = models.CharField(max_length=100,null=True,blank=True)
    Mt = models.CharField(max_length=100,null=True,blank=True)
    Mr = models.CharField(max_length=100,null=True,blank=True)
    Mb = models.CharField(max_length=100,null=True,blank=True)
    Ml = models.CharField(max_length=100,null=True,blank=True)
    Color = models.CharField(max_length=20,null=True,blank=True)
    M_Auto = models.BooleanField(null=True,blank=True)
    TextCenter = models.BooleanField(null=True,blank=True)
    Position = models.BooleanField(null=True, blank=True)
    Top = models.CharField(null=True, blank=True, max_length=30)
    Right = models.CharField(null=True, blank=True, max_length=30)
    Width = models.CharField(null=True, blank=True, max_length=30)
    Height = models.CharField(null=True, blank=True, max_length=30)



    def __str__(self):
        return str(self.TextBoxID)


class Article(models.Model):
    Title = models.CharField(max_length=500)
    Category = models.ForeignKey('Article.CategoriesArticle',on_delete=models.SET('[]'))
    DateCreate = models.DateTimeField(null=True,blank=True)
    IsShow = models.BooleanField(default=True)
    Views = models.BigIntegerField(null=True, blank=True, default=0)
    Likes = models.IntegerField(null=True, blank=True, default=0)

    def SerTimeArticle(self):
        self.DateCreate = GetTimeIran()

    def save(self,*args,**kwargs):
        if not self.pk or self.DateCreate == None:
            self.SerTimeArticle()
        super(Article,self).save(*args,**kwargs)

    def __str__(self):
        return self.Title

    def AddView(self):
        Views = int(self.Views)
        self.Views = Views + 1
        self.save()

    def AddLike(self):
        Likes = int(self.Likes)
        self.Likes = Likes + 1
        self.save()

    def MinusLike(self):
        Likes = int(self.Likes) - 1
        if Likes < 0:
            Likes = 0
        self.Likes = Likes
        self.save()

    def WordsKey(self):
        ArticleTitles = None
        ListKeyWord = []
        StateArticleDesign = ArticleDesign.objects.filter(Article_id=self.id).first()
        if StateArticleDesign is not None:
            ArticleTitles = ArticleDesign_Title.objects.filter(ArticleDesign_id=StateArticleDesign.id)
        if ArticleTitles is not None:
            for i in ArticleTitles:
                ListKeyWord.append(i.Text)
        return ListKeyWord

    def WordsKeyText(self):
        ArticleTitles = None
        StringKeyWord = ''
        StateArticleDesign = ArticleDesign.objects.filter(Article_id=self.id).first()
        if StateArticleDesign is not None:
            ArticleTitles = ArticleDesign_Title.objects.filter(ArticleDesign_id=StateArticleDesign.id)
        if ArticleTitles is not None:
            for i in ArticleTitles:
                StringKeyWord += i.Text + ','
        return StringKeyWord

    def TimePast(self):
        return GetDifferenceTime(self.DateCreate)

    def TimeRead(self):
        Art = ArticleDesign_Text.objects.filter(ArticleDesign__Article_id=self.id)
        if Art.first() is not None:
            Text = ''
            for T in Art:
                Text += T.Text
            Text_Split = Text.split(' ')
            LenWords = math.floor((len(Text_Split) / 4))  # four is zarib | every 1 sec == four words
            Minutes = int(round(LenWords / 60))
            if Minutes < 1:
                Minutes = 1
            return f'{Minutes} دقیقه '
        return 'نامشخص'

    def CommentsNumber(self):
        return len(Comment.objects.filter(Article_id=self.id,Is_Active=True).all())

    def GetComments(self):
        return Comment.objects.filter(Article_id=self.id,Is_Active=True).all()[::-1]

    def LinkArticleWithSiteAddress(self):
        return f'zehnedigital.ir/p/{self.id}'

    def LinkArticle(self):
        return f'/p/{self.id}'

    def GetArticleDesign(self):
        return ArticleDesign.objects.filter(Article_id=self.id).first()

    def LessText(self):
        StateArticleDesign = ArticleDesign.objects.filter(Article_id=self.id).first()
        if StateArticleDesign == None:
            return None
        StateArticleDesign = ArticleDesign_Text.objects.filter(ArticleDesign_id=StateArticleDesign.id)
        if StateArticleDesign.first() is not None:
            return StateArticleDesign.first().Text[:200]
        return None


class CategoriesArticle(models.Model):
    Title = models.CharField(max_length=500)

    def __str__(self):
        return self.Title

    def LinkCategory(self):
        return f'/p/Article/Articles?Category={self.id}-{self.Title}'

    def Get_4_LastRecord(self):
        return Article.objects.filter(Category_id=self.id).order_by('-id')[:4]

    def Get_8_LastRecord(self):
        return Article.objects.filter(Category_id=self.id).order_by('-id')[:8]

    def Get_All_Articles(self):
        return Article.objects.filter(Category_id=self.id).order_by('-id')






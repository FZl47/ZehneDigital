from django.urls import path
from .views import *

app_name = 'Article'
urlpatterns = [
    path('<ArticleID>',Article_View),
    path('Article/Articles',Articles_View),
    path('Article/GetImage',GetImageWithTextBoxID),
    path('Article/SubmitComment',SubmitComment),
    path('Article/LikeArticle',LikeArticle),
]
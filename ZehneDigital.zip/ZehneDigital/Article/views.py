import json
from datetime import datetime
import pytz
from django.db.models import Q
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from django.core.paginator import Paginator
from .models import *


def GetArticle(ID):
    try:
        StateArticle = Article.objects.filter(id=int(ID), IsShow=True).first()
        return StateArticle
    except:
        return None


def Article_View(request, ArticleID):
    # GetDifferenceTime(StateArticle.DateCreate)
    Context = {}
    StateArticle = GetArticle(ArticleID)
    if StateArticle == None:
        return redirect('/Err/404')
    StateArticleDesign = ArticleDesign.objects.filter(Article_id=StateArticle.id).first()
    if StateArticleDesign == None:
        return redirect('/Err/404')
    StateArticle.AddView()
    Categories = CategoriesArticle.objects.all().distinct()[:6]
    CategoriesAll = CategoriesArticle.objects.all().distinct()
    #
    CounterForLoopCategory = 0
    StateReadMores = False
    StateArticle: Article
    LookUp = Q(Category=StateArticle.Category) | Q(Title__contains=StateArticle.Title)
    ReadMores = Article.objects.filter(LookUp, IsShow=True).exclude(id__in=[StateArticle.id]).all()
    if ReadMores.first() is not None:
        StateReadMores = True
        ReadMores = ReadMores[:6]
    CounterForLoopCategory += 1
    #
    StatePopularities = False
    Popularities = Article.objects.filter(IsShow=True).order_by('-Likes').exclude(id=StateArticle.id).distinct()
    if Popularities.first() != None:
        Popularities = Popularities[:15]
        StatePopularities = True
    #
    StateRelated = False
    Relateds = Article.objects.filter(Category_id=StateArticle.Category.id, IsShow=True).exclude(
        id=StateArticle.id).distinct()
    if Relateds.first() != None:
        Relateds = Relateds[:9]
        StateRelated = True
    #
    StateSuggestions = False
    Suggestions = Article.objects.filter(IsShow=True).order_by('-Views')
    if Suggestions.first() != None:
        Suggestions = Suggestions[:9]
        StateSuggestions = True

    Context['StateSuggestions'] = StateSuggestions
    Context['Suggestions'] = Suggestions
    Context['StateRelateds'] = StateRelated
    Context['Relateds'] = Relateds
    Context['StatePopularities'] = StatePopularities
    Context['Popularities'] = Popularities
    Context['ReadMores'] = ReadMores
    Context['StateReadMores'] = StateReadMores
    Context['Article'] = StateArticle
    Context['Categories'] = Categories
    Context['CategoriesAll'] = CategoriesAll
    return render(request, 'Article.html', Context)


def ListNumber(Start, End):
    List = []
    for i in range(Start, End + 1):
        List.append(i)
    return List


def Articles_View(request):
    Context = {}
    ArticleGet = []
    CategoryGet = []
    Category = request.GET.get('Category')
    Search = request.GET.get('Search')
    AllArticle = request.GET.get('All')
    ViewsArticle = request.GET.get('Views')
    LikesArticle = request.GET.get('Likes')

    StateAll = False
    StateCategory = False
    StateSearch = False
    StateViews = False
    StateLikes = False
    UrlValue = ''
    CategoryID = ''
    if Category is not None and Category != '':
        CategoryID = Category.split('-')[0]
        CategoryTitle = ''
        try:
            CategoryTitle = Category.split('-')[1]
        except:
            pass

        ArticleGet = []
        try:
            ArticleGet = Article.objects.filter(Category_id=CategoryID,IsShow=True).all()
        except:
            pass
        StateCategory = True
        UrlValue = f'?Category={CategoryID}-{CategoryTitle}'

    if Search is not None and Search != '':
        LookUp = Q(Title__icontains=Search) | Q(Category__Title__icontains=Search)
        ArticleGet = Article.objects.filter(LookUp,IsShow=True).all()
        UrlValue = f'?Search={Search}'
        StateSearch = True

    if ViewsArticle is not None:
        ArticleGet = Article.objects.order_by('-Views')
        UrlValue = f'?Views'
        StateViews = True

    if LikesArticle is not None:
        ArticleGet = Article.objects.order_by('-Likes')
        UrlValue = f'?Likes'
        StateLikes = True

    if AllArticle is not None:
        ArticleGet = Article.objects.filter(IsShow=True).order_by('-DateCreate')
        StateAll = True
        UrlValue = f'?All'


    if not StateCategory and not StateAll and not StateSearch and not StateViews and not StateLikes:
        return redirect('/p/Article/Articles?All')
    #
    ListItemPagination = []
    PaginatorPage = Paginator(ArticleGet, 35)
    PageNumber = request.GET.get('Page') or 1
    if PageNumber != None:
        PageNumber = int(PageNumber)
    if PageNumber > PaginatorPage.num_pages:
        return redirect(f'/p/Article/Articles?{UrlValue}&Page={PageNumber}')
    if PaginatorPage.num_pages > 1:
        if PageNumber is not None:
            ListItemPagination.append(1)
            if PageNumber != 1 and PageNumber - 1 != 0:
                ListItemPagination.append(PageNumber - 1)
            else:
                ListItemPagination.append(PageNumber)
            if PageNumber != 1 and PageNumber > 1 :
                ListItemPagination.append(PageNumber)
            if PageNumber != PaginatorPage.num_pages and PageNumber + 1 != PaginatorPage.num_pages:
                ListItemPagination.append(PageNumber +1)
            ListItemPagination.append(PaginatorPage.num_pages)
            ListItemPagination = list(set(ListItemPagination))
    #
    Comments = []
    CommentsList = Comment.objects.filter(Is_Active=True).order_by('-DateTimeSubmit')
    for i in CommentsList:
        if ArticleDesign.objects.filter(Article_id=i.Article.id).first() is not None:
            Comments.append(i)
    Comments = Comments[:30]


    Context['PageListItem'] = ListItemPagination
    Context['CategoriesAll'] = CategoriesArticle.objects.all().distinct()
    Context['PageObj'] = PaginatorPage.get_page(PageNumber)
    Context['PageObjListPage'] = ListNumber(1, PaginatorPage.num_pages)
    Context['UrlValue'] = UrlValue
    Context['Comments'] = Comments
    
    try:
        Context['PageObj'][0]
    except:
        return redirect('/Err/404')
        

    return render(request, 'Articles.html', Context)


@csrf_exempt
def GetImageWithTextBoxID(request):
    if request.is_ajax():
        Context = {
            'Images': []
        }
        Status = 'NoDetect'
        Data = json.loads(request.body)

        Images = Data['Images']
        for TextBoxID in Images:
            State: ArticleDesign_Image
            State = ArticleDesign_Image.objects.filter(TextBoxID=TextBoxID).first()
            if State != None:
                Status = '200'
                try:
                    Context['Images'].append(State.Image.url)
                except:
                    Status = '500'
            else:
                Status = '500'
        Context['Status'] = Status
        return JsonResponse(Context)
    return redirect('/Err/403')


@csrf_exempt
def SubmitComment(request):
    if request.is_ajax():
        Context = {}
        Data = json.loads(request.body)
        ArticleID = int(Data.get('IDArticle'))
        Name = Data.get('Name')
        Email = Data.get('Email')
        Text = Data.get('Text')
        Replayed = Data.get('Replayed')
        ReplayedID = Data.get('ReplayedID')

        if (Name is not None and Name is not '' and Name is not ' ') and (
                Email is not None and Email is not '' and Email is not ' ') and (
                Text is not None and Text is not '' and Text is not ' '):
            StateComment = None
            if Replayed:
                ReplayedID = int(ReplayedID)
                StateCommentForReplay = Comment.objects.filter(id=ReplayedID).first()
                if StateCommentForReplay == None:
                    Context['Status'] = '500'
                else:
                    StateComment = Comment.objects.create(Article_id=ArticleID, Name=Name, Email=Email, Text=Text,
                                                          DateTimeSubmit=GetTimeIran(),
                                                          ReplayedName=StateCommentForReplay.Name,
                                                          CommentIsReplayed=True)
                    Context['Status'] = '200'
                    Context['CommentDateTime'] = StateComment.TimePast()
                    Context['CommentID'] = StateComment.id
                    Context['CommentReplayedName'] = StateCommentForReplay.Name
                    Context['CommentReplayedID'] = StateCommentForReplay.id

            else:
                StateComment = Comment.objects.create(Article_id=ArticleID, Name=Name, Email=Email,
                                                      DateTimeSubmit=TimeIran, Text=Text,
                                                      ReplayedName='',
                                                      CommentIsReplayed=False)
                Context['Status'] = '200'
                Context['CommentDateTime'] = StateComment.TimePast()
                Context['CommentID'] = StateComment.id
                Context['CommentName'] = ''
                Context['CommentReplayedID'] = ''
        return JsonResponse(Context)
    return redirect('/Err/403')


@csrf_exempt
def LikeArticle(request):
    if request.is_ajax():
        Context = {}
        Data = json.loads(request.body)
        ArticleID = int(Data.get('ArticleID'))
        Type = Data.get('Type')
        StateArticle = Article.objects.filter(id=ArticleID).first()
        if StateArticle != None:
            if Type == 'Like':
                StateArticle.AddLike()
                Context['Status'] = '200'
            else:
                StateArticle.MinusLike()
                Context['Status'] = '200'
        else:
            Context['Status'] = '500'

        return JsonResponse(Context)
    return redirect('/Err/403')



from django.urls import path
from .views import *
app_name = 'Errors'
urlpatterns = [
    path('404',View_404),
    path('403',View_403),
]
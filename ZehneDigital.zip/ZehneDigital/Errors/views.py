from django.shortcuts import render
from Article.models import CategoriesArticle


def View_404(request):
    Context = {}
    Context['AllCategories'] = CategoriesArticle.objects.all()
    return render(request,'404.html',Context)

def View_404_Exception(request,exception):
    Context = {}
    Context['AllCategories'] = CategoriesArticle.objects.all()
    return render(request, '404.html', Context)

def View_403(request):
    Context = {}
    Context['AllCategories'] = CategoriesArticle.objects.all()
    return render(request,'403.html',Context)

def View_403_Exception(request,exception):
    Context = {}
    Context['AllCategories'] = CategoriesArticle.objects.all()
    return render(request, '403.html', Context)
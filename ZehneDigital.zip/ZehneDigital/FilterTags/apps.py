from django.apps import AppConfig


class FiltertagsConfig(AppConfig):
    name = 'FilterTags'

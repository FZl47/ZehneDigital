import math

from django import template
from Article.models import *

register = template.Library()

@register.filter
@register.simple_tag()
def Length_Less(NumberGeted,Length):
    if int(NumberGeted) < int(Length):
        return True
    return False

@register.filter
@register.simple_tag()
def Length_Bigger(NumberGeted,Length):
    if int(NumberGeted) > int(Length):
        return True
    return False


@register.filter
@register.simple_tag()
def ConvertQueryDictToList(QueryDict):
    List = []
    State = None
    for i in QueryDict:
        List.append(i)
        State = True
    if State == None:
        return None
    return List


@register.filter
@register.simple_tag()
def ValueIsNone(Value):
    if Value == None or Value == '' or Value == ' ' or Value == 'None' :
        return True
    return False

@register.filter
@register.simple_tag()
def Round(Number,i):
    if Number != None and Number != '' and Number != ' ':
        D = str(round(Number,i))
        Z1 = int(D.split('.')[0])
        Z2 = int(D.split('.')[1])
        if Z2 == 0:
            return Z1
        else:
            return D
    return ''

@register.filter
@register.simple_tag()
def CheckValTagIsNone(Val):
    if Val == '' or Val == ' ' or Val == None :
        return 'TagMustNull'
    return ''

@register.filter
@register.simple_tag()
def GetValInListString(Str,Index):
    List = str(Str).split(',')
    if Index >= len(List):
        return None
    return List[Index]

@register.filter
@register.simple_tag()
def ConvertStringToList_Str(Str):
    List = str(Str).split(',')
    return List

@register.filter
@register.simple_tag()
def SearchInList(List,Value):
    List = list(List)
    for i in List:
        if Value == i:
            return i
    return None


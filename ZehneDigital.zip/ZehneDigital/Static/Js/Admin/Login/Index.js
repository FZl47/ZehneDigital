let StateDict = {
    'UserName': false,
    'Password': false
}


let BtnLogin = document.getElementById('BtnLogin')
BtnLogin.onclick = BtnLoginClick

let InputUserName = document.querySelector('input[UserName]')
let InputPassword = document.querySelector('input[Password]')
let InputSaveMe = document.querySelector('input[SaveMe]')

function CheckInput(Input, Type) {
    let Value = Input.value
    if (Value.trim() != '' && Value != ' ' && Value != null) {
        Input.setAttribute('State', 'Ok')
        if (Type == 'UserName') {
            StateDict['UserName'] = true
        }
        if (Type == 'Password') {
            StateDict['Password'] = true
        }
    } else {
        Input.setAttribute('State', 'NotOk')
        if (Type == 'UserName') {
            StateDict['UserName'] = false
        }
        if (Type == 'Password') {
            StateDict['Password'] = false
        }
    }

    CheckStateFormLogin()
}


function CheckStateFormLogin() {
    let ValueUserName = InputUserName.value
    let ValuePassword = InputPassword.value

    if (ValueUserName.trim() != '' && ValueUserName != ' ' && ValueUserName != null && ValuePassword.trim() != '' && ValuePassword != ' ' && ValuePassword != null) {
        BtnLogin.classList.remove('BtnIsNotOk')
        BtnLogin.classList.add('BtnIsOk')
    } else {
        BtnLogin.classList.add('BtnIsNotOk')
        BtnLogin.classList.remove('BtnIsOk')
    }
}


function BtnLoginClick() {
    if (StateDict['UserName'] && StateDict['Password']) {
        let Data = {'UserName': InputUserName.value, 'Password': InputPassword.value}
        SendAjax('/AdminPanel/Login/Check', Data, 'POST', function (response) {
            if (response.Status == '200') {
                if (InputSaveMe.checked) {
                    SetCookie('qazRWxN', response.qazRWxN, 50, '')
                    SetCookie('sZTyJLp', response.sZTyJLp, 50, '')
                } else {
                    SetCookie('qazRWxN', response.qazRWxN, 'Session', '')
                    SetCookie('sZTyJLp', response.sZTyJLp, 'Session', '')
                }
                location.href = '/AdminPanel'
            } else if (response.Status == '404') {
                ShowNotificationMessage('نام کاربری یا گذرواژه شما اشتباه میباشد', 'Error', 7000, 3)
            }
        })
    }
}

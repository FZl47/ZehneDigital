let ListObjectsArticleGet = []

class CategoryArticlesGeted {
    constructor(ID, NodeArticles, LengthArticle) {
        this.ID = ID
        this.NodeArticles = NodeArticles
        this.LengthArticle = LengthArticle
        ListObjectsArticleGet.push(this)
    }
}

function CheckCategoryArticleInList(ID) {
    let Object = null
    for (let i of ListObjectsArticleGet) {
        if (i.ID == ID) {
            Object = i
            break
        }
    }
    return {'Object': Object, 'State': Object == null ? false : true}
}

function AllArticleCategory(ID, Name) {
    let BtnAllArticles = document.getElementById(`BtnAllArticles_${ID}`)
    BtnAllArticles.setAttribute('disabled', '')
    let ContainerBlur = CreateContainerBlur()
    let ContainerArticles = document.createElement('div')
    ContainerArticles.className = 'text-center'
    ContainerArticles.setAttribute('id', 'ContainerArticlesCategory')
    let TitleContainerArticles = document.createElement('h5')
    TitleContainerArticles.innerText = Name
    TitleContainerArticles.className = 'text-center'
    let CounterArticle = document.createElement('p')
    CounterArticle.className = 'CounterArticleGet'
    ContainerBlur.appendChild(CounterArticle)
    ContainerBlur.appendChild(TitleContainerArticles)
    let StateCategoryGet = CheckCategoryArticleInList(ID)
    if (StateCategoryGet['State']) {
        CounterArticle.innerHTML = `تعداد :    <b>${StateCategoryGet['Object']['LengthArticle']}</b>`
        ContainerArticles.appendChild(StateCategoryGet['Object']['NodeArticles'])
        ContainerBlur.appendChild(ContainerArticles)
        ClickOutSideContainer(ContainerBlur, function () {
            ClearEffectOnBody()
            DeleteContainerBlur()
            BtnAllArticles.removeAttribute('disabled')
        })
        ScrollOnElement('ContainerArticlesCategory')
    } else {
        let Data = {'CategoryID': ID, 'TypeGet': 'Category'}
        SendAjax('GetArticle', Data, 'POST', function (response) {
            if (response.Status == '200') {
                for (let Article of response.Articles) {
                    ContainerArticles.innerHTML += CreateArticle(Article.id, Article.Title, Article.DateCreate, Article.IsShow)
                }
                CounterArticle.innerHTML = `تعداد :    <b>${response.Articles.length}</b>`
                new CategoryArticlesGeted(ID, ContainerArticles, response.Articles.length)
                ContainerBlur.appendChild(ContainerArticles)
                ClickOutSideContainer(ContainerBlur, function () {
                    ClearEffectOnBody()
                    DeleteContainerBlur()
                    BtnAllArticles.removeAttribute('disabled')
                })
                ScrollOnElement('ContainerArticlesCategory')
            }
        })
    }
}

function SearchArticle(Input) {
    ClearEffectOnBody()
    DeleteContainerBlur()
    let Text = Input.value
    if (Text.trim() != '' && Text != ' ') {
        let Data = {'TypeGet': 'Search', 'TextSearch': Text}
        SendAjax('GetArticle', Data, 'POST', function (response) {
            if (response.Status == '200') {
                let ContainerBlur = CreateContainerBlur(10)
                ClickOutSideContainer(ContainerBlur, function () {
                    ClearEffectOnBody()
                    DeleteContainerBlur()
                })
                let ContainerArticlesSearch = document.createElement('div')
                ContainerArticlesSearch.className = 'text-center'
                let StateNullArticles = false
                for (let Article of response.Articles) {
                    ContainerArticlesSearch.innerHTML += CreateArticle(Article.id, Article.Title, Article.DateCreate, Article.IsShow)
                    StateNullArticles = true
                }
                if (!StateNullArticles) {
                    ContainerArticlesSearch.innerHTML = '<div class="ContainerNotFoundContent text-light"><div>موردی یافت نشد</div></div>'
                }
                ContainerBlur.appendChild(ContainerArticlesSearch)
            }
        })
    }
}

function CreateArticle(ID, Title, DateCreate, IsShow) {
    let Node = `
                        <div class="Article col-sm-5 d-inline-block m-1 text-right Content ${IsShow == false ? 'Article_NotShow' : ''}"
                        onclick="GoToUrl('/AdminPanel/Obj/Article/${ID}')">
                            <p class="DateTimeCreate">${DateCreate}</p>
                            <p class="TitleArticle">${TrunCateLetter(Title, 20)}</p>
                        </div>
                        `
    return Node
}

function ShowDropDown(Element) {
    let ContainerDropDown = Element.querySelector('[ContainerDropDown]')
    ContainerDropDown.classList.toggle('ContainerDropDownToggle')

}

function HideAllContainer() {
    let AllContainer = document.querySelectorAll('[Container]')
    for (let i of AllContainer) {
        i.classList.add('ContainerHide')
    }
    RemoveIconActiveAside()
}

function RemoveIconActiveAside() {
    let AllIconBtnAside = document.querySelectorAll('[IconBtnAside]')
    for (let i of AllIconBtnAside) {
        i.classList.remove('IconActiveAside')
    }
}

function ShowContainer(Type) {
    HideAllContainer()
    if (Type == 'WithoutDesign') {
        let Container = document.querySelector('[ContainerPostWithoutDesign]')
        document.querySelector('[IconBtnAsideWithoutDesign]').classList.add('IconActiveAside')
        Container.classList.remove('ContainerHide')
        Container.classList.add('ContainerShow')
    } else if (Type == 'Design') {
        let Container = document.querySelector('[ContainerDesign]')
        document.querySelector('[IconBtnDesign]').classList.add('IconActiveAside')
        Container.classList.remove('ContainerHide')
        Container.classList.add('ContainerShow')
    } else if (Type == 'Comments') {
        let Container = document.querySelector('[ContainerComments]')
        document.querySelector('[IconBtnComments]').classList.add('IconActiveAside')
        Container.classList.remove('ContainerHide')
        Container.classList.add('ContainerShow')
    } else if (Type == 'SupportMessage') {
        let Container = document.querySelector('[ContainerSupportMessage]')
        document.querySelector('[InoutSupportMessage]').classList.add('IconActiveAside')
        Container.classList.remove('ContainerHide')
        Container.classList.add('ContainerShow')
    }
}

function OpenComment(ID, CommentText, Name, Email, Is_Check, Is_Active, ArticleTitle, ArticleLink, DateCreate) {

    let Node = `
                <div class="ContainerComment" id="ContainerComment_${ID}">
        <i class="fa fa-times IconCloseComment" onclick="CloseContainerComment()"></i>
        <div class="ContainerCommentInfo">
            <h5 class="CommentName">
                ${Name}
            </h5>
            <p class="CommentEmail">
                ${Email}
            </p>
            <p class="DateTimeCreate">
                <i class="far fa-clock"></i>
                ${DateCreate}
               </p>
        </div>
        <a href="${ArticleLink}" class="LinkArticleComment">${ArticleTitle}</a>
        <br>
        <div class="CommentText">
            ${CommentText}
        </div>
        <br>
        <div class="ContainerCommentCheck">
            <div class="ContainerInputComment">
                <p class="Label">چک شده</p>
                <input type="checkbox" CommentChecked>
            </div>
            <div class="ContainerInputComment">
                <p class="Label">فعال</p>
                <input type="checkbox" ${Is_Active == 'True' ? 'checked' : ''} CommentActive>
            </div>
        </div>
        <div class="ContainerBtnComment">
            <button class="BtnStyleAlert_1" onclick="CreateMessage_Alert('ایا از حذف کردن نظر اطمینان دارید ؟',RemoveComment,'${ID}',BlurBodyExceptContainerComment)">
                حذف
            </button>
            <button class="BtnStyle_5" onclick="SubmitCommentCheckState('${ID}')">
                ثبت
            </button>
        </div>
    </div>`
    document.body.innerHTML += Node
    BlurBodyExceptContainerComment()
}


function RemoveComment(ID) {

    let Data = {'ID': ID}
    SendAjax('RemoveComment', Data, 'POST', function (response) {
        if (response.Status == '200') {
            CloseContainerComment()
            ShowNotificationMessage('نظر با موفقیت حذف شد', 'Success')
            document.querySelector(`#CommentMain_${ID}`).remove()
        } else if (response.Status == '404') {
            CloseContainerComment()
            ShowNotificationMessage('شناسه نظر نامعتبر است', 'Error')
        } else if (response.Status == '500') {
            CloseContainerComment()
            ShowNotificationMessage('مشکلی پیش امده است', 'Error')
        }
    })
}

function SubmitCommentCheckState(ID) {
    let ContainerComment = document.querySelector(`#ContainerComment_${ID}`)
    let CommentChecked = ContainerComment.querySelector('[CommentChecked]').checked
    let CommentActive = ContainerComment.querySelector('[CommentActive]').checked
    let Data = {
        'ID': ID,
        'Checked': CommentChecked,
        'Active': CommentActive
    }
    SendAjax('SubmitInfoComment', Data, 'POST', function (response) {
        if (response.Status == '200') {
            CloseContainerComment()
            ShowNotificationMessage('تغیرات نظر با موفقیت انجام شد', 'Success')
            document.querySelector(`#CommentMain_${ID}`).classList.add('d-none')
        } else if (response.Status == '404') {
            CloseContainerComment()
            ShowNotificationMessage('شناسه نظر نامعتبر است', 'Error')
        } else if (response.Status == '500') {
            CloseContainerComment()
            ShowNotificationMessage('مشکلی پیش امده است', 'Error')
        }
    })
}


function BlurBodyExceptContainerComment() {
    document.body.classList.add('BlurAllElementExceptContainerComment')
}

function RemoveBlurBodyExceptContainerComment() {
    document.body.classList.remove('BlurAllElementExceptContainerComment')
}


function CloseContainerComment() {
    let ContainerComments = document.getElementsByClassName('ContainerComment')
    for (let i of ContainerComments) {
        i.remove()
    }
    RemoveBlurBodyExceptContainerComment()
}
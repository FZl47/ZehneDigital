SplitPrice()

function FocusInputForm(Element) {
    Element.classList.add('ContainerInputIconActive')
}

function FocusOutInputForm(Element) {
    Element.classList.remove('ContainerInputIconActive')
}

function ReplayComment(ID, Name) {
    let ContainerReplayed = document.querySelector('[ContainerReplayed]')
    ContainerReplayed.removeAttribute('hidden')
    ContainerReplayed.querySelector('.ReplayedName').innerHTML = Name
    ContainerReplayed.querySelector('[Comment_Replayed]').value = ID
    ScrollOnElement('ContainerFormSendComment')
}

function RemoveReplayComment() {
    let ContainerReplayed = document.querySelector('[ContainerReplayed]')
    ContainerReplayed.setAttribute('hidden', '')
    ContainerReplayed.querySelector('[Comment_Replayed]').value = '_NoReplay'
}

function CreateComment(DateTimeSubmit, Name, CommentIsReplayed = false, ReplayedName = ' ', Text, ID, IDReplayed) {
    let NodeReplay = ``
    if (CommentIsReplayed) {
        NodeReplay = `
                    <div class="ContainerReplayed">
                                <p class="LabelContainerReplayed">در پاسخ به :</p>
                                <p class="ReplayedName">${ReplayedName}</p>
                    </div>
                `
    }
    let Node = `
                <div class="Comment col-sm-12 col-md-11 mx-auto" id="Comment_${ID}">
                <img src="/Static/Image/Background/BackgroundMore/ImageUser_2.jpg" class="ImageUserComment"
                             alt="User">
                    <div class="ContainerDateTimeSubmit">
                        <i class="far fa-clock"></i>
                        <p>${DateTimeSubmit}</p>
                    </div>
                    <div class="ContainerComment_Name">
                        <p class="d-inline-block">  ${Name} </p>
                        ${NodeReplay}
                    </div>
                    <div class="ContainerComment_Text">
                        <p>
                            ${Text}
                        </p>
                    </div>
                    <div class="ContainerReplay">
                        <div onclick="ReplayComment('${ID}','${Name}')">
                            <i class="far fa-reply" title="پاسخ"></i>
                            <p>پاسخ</p>
                        </div>
                    </div>
                </div>
            `
    let Container = document.getElementById('Comments')
    Container.insertAdjacentHTML('beforebegin', Node)
}


function SetSrcImages() {
    let ImagesData = {
        'Images': []
    }
    let AllImages = document.querySelector('#_Admin__Container__Node').querySelectorAll('img')
    for (let Image of AllImages) {
        let TextBoxID = Image.getAttribute('id')
        ImagesData.Images.push(TextBoxID)
    }
    SendAjax('/p/Article/GetImage', ImagesData, 'POST', SetSrcImagesGeted)

    function SetSrcImagesGeted(response) {
        if (response.Status == '200') {
            let ListSrc = response.Images
            let CounterLoopImage = 0
            for (let Image of AllImages) {
                Image.setAttribute('src', ListSrc[CounterLoopImage])
                Image.setAttribute('Src_Past', ListSrc[CounterLoopImage])
                SetWidthImageForMobileSize(Image)
                SetOnClickImageForFullScreen(Image)
                CounterLoopImage++
            }
        }
    }

}

SetSrcImages()

function SetWidthImageForMobileSize(Image) {
    if (window.innerWidth < 540) {
        let W1 = parseInt(String(Image.style.width).split('%')[0])
        let Mr = parseInt(String(Image.style.marginRight).split('%')[0])
        if (W1 < 70) {
            Image.style.width = W1 + 23 + '%'
            if (Mr > 9.5){
                Image.style.marginRight = Mr - 9.5 + '%'
            }
        }
    }
}

function SetOnClickImageForFullScreen(Image) {
    Image.setAttribute('onclick','OpenFullscreen(this)')
}


let DictStateComment = {
    'Name': false,
    'Email': false,
    'Text': false
}

function ValidationInput(Element, Input, Type) {

    let Value = Input.value
    let IconState = Element.querySelector('i')
    if (Type == 'Name') {
        if (Value != '' && Value != ' ' && Value != null && Value.trim() != '') {
            IconState.className = 'fal fa-check-circle IconStateInput'
            Input.setAttribute('State', 'Ok')
            DictStateComment['Name'] = true
        } else {
            IconState.className = 'fal fa-times-circle IconStateInput'
            Input.setAttribute('State', 'NotOk')
            DictStateComment['Name'] = false
        }
    }
    if (Type == 'Email') {
        if (ValidationEmail(Value) && Value.trim() != '') {
            IconState.className = 'fal fa-check-circle IconStateInput'
            Input.setAttribute('State', 'Ok')
            DictStateComment['Email'] = true

        } else {
            IconState.className = 'fal fa-times-circle IconStateInput'
            Input.setAttribute('State', 'NotOk')
            DictStateComment['Email'] = false
        }
    }
    if (Type == 'Text') {
        if (Value != '' && Value != ' ' && Value != null && Value.trim() != '') {
            IconState.className = 'fal fa-check-circle IconStateInput'
            Input.setAttribute('State', 'Ok')
            DictStateComment['Text'] = true
        } else {
            IconState.className = 'fal fa-times-circle IconStateInput'
            Input.setAttribute('State', 'NotOk')
            DictStateComment['Text'] = false
        }
    }
    StateFormSendComment()
}

function StateFormSendComment() {
    let BtnSubmit = document.querySelector('.ContainerFormSendComment [Comment_Btn]')
    if (DictStateComment['Name'] && DictStateComment['Email'] && DictStateComment['Text']) {
        BtnSubmit.className = 'Btn_Style_3 Btn_Style_Active_1'
        BtnSubmit.setAttribute('onclick', 'SubmitComment()')
    } else {
        BtnSubmit.className = 'Btn_Style_Disabled_1 Btn_Style_3'
        BtnSubmit.removeAttribute('onclick')
    }
}

let ArticleID = document.querySelector('[Article_ID]').value

function GetIsLikeArticle() {
    let ListArticleLike = GetCookieByName('LikeListArticle')
    if (ListArticleLike != null) {
        ListArticleLike = ListArticleLike.split(',')
        if (ValueInList(ListArticleLike, ArticleID)) {
            let ContainerLikeArticle = document.getElementById('ContainerLikeArticle')
            ContainerLikeArticle.querySelector('i').className = 'fas fa-heart'
            ContainerLikeArticle.classList.add('ContainerLiked')
            ContainerLikeArticle.setAttribute('State', 'RemoveLike')
            let TextsInElement = ContainerLikeArticle.querySelectorAll('p')
            TextsInElement[0].innerText = 'پسندیدم'
            TextsInElement[1].innerText = 'پسندیدم'
        }
    }
}

GetIsLikeArticle()


function LikeArticle(Element) {
    let Icon = Element.querySelector('i')
    let State = Element.getAttribute('State')
    if (State == 'Like') {
        let Data = {
            'ArticleID': ArticleID,
            'Type': 'Like'
        }
        SendAjax('/p/Article/LikeArticle', Data, 'POST', function (response) {
            if (response.Status == '200') {
                let LikeListArticle = []
                let LikePastList = GetCookieByName('LikeListArticle')
                if (LikePastList != null) {
                    LikeListArticle = LikePastList.split(',')
                }
                LikeListArticle.push(ArticleID)
                SetCookie('LikeListArticle', LikeListArticle, 1000000)
                Icon.className = 'fas fa-heart'
                Element.setAttribute('State', 'RemoveLike')
                Element.classList.add('ContainerLiked')
                let TextsInElement = Element.querySelectorAll('p')
                TextsInElement[0].innerText = 'پسندیدم'
                TextsInElement[1].innerText = 'پسندیدم'
            } else {
                ShowNotificationMessage('مشکلی پیش امده است', 'Error', 5000, 3)
            }
        })

    } else {
        let Data = {
            'ArticleID': ArticleID,
            'Type': 'RemoveLike'
        }
        SendAjax('/p/Article/LikeArticle', Data, 'POST', function (response) {
            if (response.Status == '200') {
                let LikePastList = GetCookieByName('LikeListArticle')
                if (LikePastList != null) {
                    let LikeListArticle = LikePastList.split(',')
                    LikeListArticle = RemoveInList(LikeListArticle, LikeListArticle.indexOf(String(ArticleID)))
                    SetCookie('LikeListArticle', LikeListArticle, 1000000)
                }
                Icon.className = 'far fa-heart'
                Element.setAttribute('State', 'Like')
                Element.classList.remove('ContainerLiked')
                let TextsInElement = Element.querySelectorAll('p')
                TextsInElement[0].innerText = 'پسندیدن'
                TextsInElement[1].innerText = 'پسندیدن'
            } else {
                ShowNotificationMessage('مشکلی پیش امده است', 'Error', 5000, 3)
            }
        })
    }
}


function SubmitComment() {
    let IDArticle = document.querySelector('[Article_ID]').value
    let Name = document.querySelector('[Comment_Name]').value
    let Email = document.querySelector('[Comment_Email]').value
    let Text = document.querySelector('[Comment_Text]').value
    let ReplayedID = document.querySelector('[Comment_Replayed]').value
    let Replayed = (ReplayedID == '_NoReplay') ? false : true;
    let Data = {
        'IDArticle': IDArticle,
        'Name': Name,
        'Email': Email,
        'Text': Text,
        'ReplayedID': ReplayedID,
        'Replayed': Replayed
    }

    SendAjax('/p/Article/SubmitComment', Data, 'POST', CommentIsSubmited)
    DisabledInputComment()
    ShowLoading()


    function CommentIsSubmited(response) {
        RemoveLoading()
        RemoveValueInputComment()
        CreateComment(response.CommentDateTime, Name, Replayed, response.CommentReplayedName, Text, response.CommentID, response.CommentReplayedID)
        ShowNotificationMessage('نظر ارزشمند شما با موفقیت ثبت شد', 'Success', 5000, 3)
        OnDisabledInputComment()
    }
}

function DisabledInputComment() {
    let Name = document.querySelector('[Comment_Name]')
    let Email = document.querySelector('[Comment_Email]')
    let Text = document.querySelector('[Comment_Text]')
    let ButtonSubmit = document.querySelector('[Comment_Btn]')
    Name.setAttribute('disabled', '')
    Email.setAttribute('disabled', '')
    Text.setAttribute('disabled', '')
    ButtonSubmit.setAttribute('disabled', '')
}

function OnDisabledInputComment() {
    let Name = document.querySelector('[Comment_Name]')
    let Email = document.querySelector('[Comment_Email]')
    let Text = document.querySelector('[Comment_Text]')
    let ButtonSubmit = document.querySelector('[Comment_Btn]')
    Name.removeAttribute('disabled')
    Email.removeAttribute('disabled')
    Text.removeAttribute('disabled')
    ButtonSubmit.removeAttribute('disabled')
}

function RemoveValueInputComment() {
    let Name = document.querySelector('[Comment_Name]')
    let Email = document.querySelector('[Comment_Email]')
    let Text = document.querySelector('[Comment_Text]')
    Name.value = null
    Email.value = null
    Text.value = null
    ResetFormComment()
}

function ResetFormComment() {
    let Name = document.querySelector('[Comment_Name]')
    let Email = document.querySelector('[Comment_Email]')
    let Text = document.querySelector('[Comment_Text]')
    ValidationInput(Name.parentNode, Name, 'Name')
    ValidationInput(Email.parentNode, Email, 'Email')
    ValidationInput(Text.parentNode, Text, 'Text')
}


function ValidationEmail(Email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(Email).toLowerCase());
}
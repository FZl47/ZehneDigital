    function CreateMessage_Alert(Text, FuncWhenOK, ValueFunc = null, FuncWhenCancel = null) {
        CloseMessage_Alert()
        document.body.className = ''

        let Container = document.createElement('div')
        let TextMessage = document.createElement('p')
        let BtnClose = document.createElement('button')
        let BtnOk = document.createElement('button')
        let BtnClose1 = document.createElement('i')


        Container.className = 'ContainerMessage_Alert'
        TextMessage.className = 'TextMessage_Alert'
        BtnClose.className = 'BtnClose_Alert BtnStyle_1'
        BtnOk.className = 'BtnOk_Alert BtnStyle_1'
        BtnClose1.className = 'fa fa-times BtnClose1_Alert'

        TextMessage.innerHTML = Text
        BtnClose.innerText = 'بازگشت'
        BtnOk.innerText = 'بله'

        BtnClose.onclick = function () {
            if (FuncWhenCancel != null) {
                FuncWhenCancel()
            }
            CloseMessage_Alert()
        }
        BtnClose1.onclick = function () {
            if (FuncWhenCancel != null) {
                FuncWhenCancel()
            }
            CloseMessage_Alert()
        }

        BtnOk.onclick = function () {
            if (ValueFunc != null) {
                FuncWhenOK(ValueFunc)
            } else {
                FuncWhenOK()
            }
            CloseMessage_Alert()
        }

        Container.appendChild(TextMessage)
        Container.appendChild(BtnClose)
        Container.appendChild(BtnClose1)
        Container.appendChild(BtnOk)
        document.body.insertBefore(Container, document.body.firstElementChild)
        BlurAllElementsExceptMessage_Alert()

    }

    function CloseMessage_Alert() {

        try {
            document.getElementsByClassName('ContainerMessage_Alert')[0].remove()
        } catch (e) {
        }
        Clear_BlurAllElementsExceptMessage_Alert()
    }

    function BlurAllElementsExceptMessage_Alert() {
        document.body.classList.add('BlurAllElementsExceptMessage_Alert')
        document.body.style.overflow = 'hidden'
    }

    function Clear_BlurAllElementsExceptMessage_Alert() {
        document.body.classList.remove('BlurAllElementsExceptMessage_Alert')
        document.body.style.overflow = ''
    }


    ////////////////////////////////////   Slider       /////////////////////////////////

    let Sliders = document.querySelectorAll('.Sliders')
    for (let i of Sliders) {
        i.setAttribute('LengthSlider', i.querySelectorAll('.Slider').length)
        i.setAttribute('IndexElementActive', '0')
        if (i.getAttribute('Timer') != null && i.getAttribute('Timer') != '') {
            i.setAttribute('StateTimer', 'Active')
            TimingSlider(i)
        }
    }


    function ChangeSlider(ContainerSlider, Type, Btn) {
        let LenSlider = ContainerSlider.querySelectorAll('.Slider').length
        if (LenSlider != '0') {


            ContainerSlider.setAttribute('StateTimer', 'Disabled')

            if (Btn == 'Active') {
                let Prev_Next = null
                if (Type == 'Next') {
                    ContainerSlider.setAttribute('IndexElementActive', Number(ContainerSlider.getAttribute('IndexElementActive')) - 1)
                    Prev_Next = -1
                } else {
                    ContainerSlider.setAttribute('IndexElementActive', Number(ContainerSlider.getAttribute('IndexElementActive')) + 1)
                    Prev_Next = 1
                }
                if (Number(ContainerSlider.getAttribute('IndexElementActive')) < 0) {
                    ContainerSlider.setAttribute('IndexElementActive', 0)
                }
                let Sliders = ContainerSlider.querySelectorAll('.Slider')
                let ElementActive = ContainerSlider.querySelector('.SliderActive')
                let IndexNextElementActive = Array.prototype.slice.call(Sliders).indexOf(ElementActive) + Prev_Next
                ElementActive.classList.remove('SliderActive')
                try {
                    Sliders[IndexNextElementActive].classList.add('SliderActive')
                } catch (e) {
                    Sliders[0].classList.add('SliderActive')
                }


                if (Number(ContainerSlider.getAttribute('LengthSlider')) - 1 == ContainerSlider.getAttribute('IndexElementActive')) {
                    ContainerSlider.querySelector('.BtnPrevSlider').setAttribute('State', 'Disabled')
                } else {
                    ContainerSlider.querySelector('.BtnPrevSlider').setAttribute('State', 'Active')
                }

                if (ContainerSlider.getAttribute('IndexElementActive') == 0) {
                    ContainerSlider.querySelector('.BtnNextSlider').setAttribute('State', 'Disabled')
                } else {
                    ContainerSlider.querySelector('.BtnNextSlider').setAttribute('State', 'Active')
                }
            }
            ContainerSlider.setAttribute('StateTimer', 'Active')
        }
    }

    function TimingSlider(Slider) {
        let StateTimer = Slider.getAttribute('StateTimer')
        let Timer = Slider.getAttribute('Timer')
        setInterval(function () {
            if (StateTimer == 'Active') {
                let BtnPrevSlider = Slider.querySelector('.BtnPrevSlider')
                let BtnNextSlider = Slider.querySelector('.BtnNextSlider')
                let IndexElementActive = Number(Slider.getAttribute('IndexElementActive'))
                let LengthSlider = Number(Slider.getAttribute('LengthSlider'))

                ChangeSlider(Slider, 'Prev', BtnPrevSlider.getAttribute('State'))

                if (IndexElementActive == LengthSlider - 1) {
                    BtnNextSlider.setAttribute('State', 'Disabled')
                    Slider.children[IndexElementActive].classList.remove('SliderActive')
                    Slider.firstElementChild.classList.add('SliderActive')
                    Slider.setAttribute('IndexElementActive', 0)
                    BtnPrevSlider.setAttribute('State', 'Active')
                }
            }
        }, Timer)
    }

    function ScrollOnElement(ID_Element) {
        document.getElementById(ID_Element).scrollIntoView()
    }

    function GoToTopPage() {
        window.scrollTo(0, 0)
    }

    function GoToUrl(Url, Target = 'Self') {

        if (Target == 'Self') {
            window.location.href = Url
        } else if (Target == 'Blank') {
            window.open(Url, '_blank')
        }
    }

    function GoToProduct(Slug) {
        window.open(`/Product/${Slug}`, '_blank');
    }


    function CloseContainerProducts(ID_Container) {
        document.getElementById(ID_Container).classList.add('d-none')
        ClearEffectOnBody()
    }

    function ClearEffectOnBody() {
        document.body.removeAttribute('class')
    }


    function SendAjax(Url, Data, Method = 'POST', Success, Failed) {

        function __Redirect__(response) {
            if (response.__Redirect__ == 'True') {
                setTimeout(function () {
                    window.location.href = response.__RedirectURL__
                }, parseInt(response.__RedirectAfter__ || 0))
            }
        }

        if (Success == undefined) {
            Success = function (response) {
                __Redirect__(response)
            }
        }
        if (Failed == undefined) {
            Failed = function (response) {
                ShowNotificationMessage('ارتباط با سرور بر قرار نشد ', 'Error', 30000, 2)
            }
        }
        $.ajax(
            {
                url: Url,
                data: JSON.stringify(Data),
                type: Method,
                success: function (response) {
                    __Redirect__(response)
                    Success(response)
                },
                failed: function (response) {
                    __Redirect__(response)
                    Failed(response)
                },
                error: function (response) {
                    __Redirect__(response)
                    Failed(response)
                    RemoveLoading()
                }
            }
        )
    }

    function ShowNotificationMessage(Text, Type, Timer = 5000, LevelOfNecessity = 2) {
        RemoveAllNotifications()

        let ContainerMessage = document.createElement('div')
        let Message = document.createElement('p')
        let BtnClose = document.createElement('i')


        ContainerMessage.classList.add('NotificationMessage')
        ContainerMessage.classList.add(`LevelOfNecessity_${LevelOfNecessity}`)
        ContainerMessage.classList.add(`Notification${Type}`)
        Message.innerText = Text
        BtnClose.className = 'fa fa-times BtnCloseNotification'


        ContainerMessage.appendChild(BtnClose)
        ContainerMessage.appendChild(Message)
        document.body.appendChild(ContainerMessage)
        setTimeout(function () {
            ContainerMessage.remove()
        }, Timer)

        BtnClose.onclick = function () {
            ContainerMessage.remove()
        }
    }

    function RemoveAllNotifications() {
        try {
            document.getElementsByClassName('NotificationMessage')[0].remove()
            document.getElementsByClassName('NotificationMessage')[1].remove()
        } catch (e) {
        }
    }

    function ValidListInputs(Inputs) {
        let State = true
        for (let Input of Inputs) {
            let Valid = Input.getAttribute('Valid')
            if (Valid == false || Valid == null || Valid == undefined) {
                State = false
            }
        }
        return State
    }

    function IsBlank(Value) {
        return (!Value || /^\s*$/.test(Value));
    }

    function CheckInputValidations(Input, Bigger, Less, SetIn = 'Input') {


        let State
        let Value = Input.value
        let ValueLength = Value.length
        if (Value != '' && Value != ' ' && Value != null && Value != undefined && IsBlank(Value) != true) {
            if (ValueLength < Less && ValueLength > Bigger) {
                State = true
            } else {
                State = false
            }
        } else {
            State = false
        }

        if (SetIn != 'None') {
            if (SetIn == 'Container') {
                Input = Input.parentNode
            }
            if (State == true) {
                Input.classList.add('InputValid')
            } else {
                Input.classList.remove('InputValid')
            }
        }


        Input.setAttribute('Valid', State)
        return State
    }

    //////////////////////////////////                  Scroll          ///////////////////////////////////////////////

    let HeightWindowBaseTemplate = window.innerHeight
    window.onscroll = function () {
        if (window.scrollY > HeightWindowBaseTemplate) {
            document.getElementById('ButtonGoToTopPage').classList.add('ButtonGoToTopIsShow')
        } else {
            document.getElementById('ButtonGoToTopPage').classList.remove('ButtonGoToTopIsShow')
        }
    }


    function SetCookieFunctionality_ShowNotification(Text, Type, Timer, LevelOfNecessity) {
        document.cookie = `Functionality_N=${Text}~${Type}~${Timer}~${LevelOfNecessity};path=/`
    }


    function GetCookieFunctionality_ShowNotification() {
        let AllCookies = document.cookie.split(';')
        let Cookie_Key
        let Cookie_Val
        for (let Co of AllCookies) {
            let Key = Co.split('=')[0]
            let Value = Co.split('=')[1]
            if (Key == 'Functionality_N' || Key == ' Functionality_N' || Key == ' Functionality_N ') {
                Cookie_Key = Key
                Cookie_Val = Value
            }
        }
        let Text
        let Type
        let Timer
        let LevelOfNecessity
        try {
            Text = Cookie_Val.split('~')[0] || 'نا مشخص'
            Type = Cookie_Val.split('~')[1] || 'Warning'
            Timer = Cookie_Val.split('~')[2] || 8000
            LevelOfNecessity = Cookie_Val.split('~')[3] || 2
        } catch (e) {
        }
        if (Cookie_Key == 'Functionality_N' || Cookie_Key == ' Functionality_N' || Cookie_Key == ' Functionality_N ') {
            ShowNotificationMessage(Text, Type, Timer, LevelOfNecessity)
        }
        document.cookie = `${Cookie_Key}=Closed; expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/`
    }


    ////////////////////////////////////// Remove In  List //////////////////////////////////////////////////

    function RemoveInList(List, Index) {
        let Counter = 0
        Index = parseInt(Index)
        let NewList = []
        for (let i of List) {
            if (Counter != Index) {
                NewList.push(i)
            }
            Counter++
        }
        return NewList
    }

    //////////////////////////////////   List Is None ///////////////////////////////////////////////////////////

    function ListIsNone(List) {
        let State = false
        if (List[0] == undefined) {
            State = true
        }
        return State
    }

    ////////////////////////////////////   Value in  List  ///////////////////////////////////////////////////

    function ValueInList(List, Value) {
        let State = false
        List.filter(function (e) {
            if (e == Value) {
                State = true
            }
        })
        return State
    }

    ////////////////////////////////////  Replace With Index  ///////////////////////////////////////////////
    String.prototype.ReplaceWithIndex = function (StartIndex, EndIndex, NewStr) {
        return this.substring(0, StartIndex) + NewStr + this.substring(EndIndex);
    };


    /////////// Get Value in Attribute ToHref in Element in Redirect To Value Geted  ///////////////////////

    function GoToUrlElement(This) {
        let Href = This.getAttribute('ToHref')
        GoToUrl(Href, 'Blank')
    }

    /////////////////////////////    Loading Notification  /////////////////////////////////////////////////

    function ShowLoading() {
        let ContainerLoading = document.createElement('div')
        let IconLoading = document.createElement('i')
        let P = document.createElement('p')


        ContainerLoading.className = 'LoadingNotification'
        IconLoading.className = 'fal fa-spinner fa-spin LoadingNotification_Icon'
        P.className = 'LoadingNotification_Text'

        P.innerText = 'لطفا صبر کنید'

        ContainerLoading.appendChild(IconLoading)
        ContainerLoading.appendChild(P)
        document.body.appendChild(ContainerLoading)
        document.body.classList.add('DisabledAllElementsExceptLoadingNotification')
    }


    function RemoveLoading() {
        let ElementLoading = document.getElementsByClassName('LoadingNotification')[0]
        ElementLoading.remove()
        document.body.classList.remove('DisabledAllElementsExceptLoadingNotification')
    }

    //////////////////////////////////        Cookie          ////////////////////////////////////////

    function GetCookieByName(Name) {
        let Res = null
        let Cookie = document.cookie
        for (let i of Cookie.split(';')) {
            let S1 = i.split('=')[0]
            let S2 = i.split('=')[1]
            if (S1 == Name || S1 == ` ${Name}` | S1 == `${Name} `) {
                Res = S2
            }
        }
        return Res
    }

    function SetCookie(Name, Value, ExpireDay, Path = '/') {
        let T = new Date()
        T.setTime(T.getTime() + (ExpireDay * 24 * 60 * 60 * 1000))
        T = T.toUTCString()
        if (ExpireDay == 'Session') {
            T = ''
        }
        document.cookie = `${Name}=${Value};expires=${T};path=${Path}`
    }

    ////////////////////////////  Split Number   /////////////////////////////////////////////////////////

    function SplitPrice(Element = null) {
        let SplitPriceNumber
        if (Element == null) {
            SplitPriceNumber = document.getElementsByClassName('SplitNumber')
        } else {
            SplitPriceNumber = new Array(Element)
        }
        for (let P of SplitPriceNumber) {
            let ListChar = []
            let Price = String(P.getAttribute('Number'))
            let Result = Price
            let LengthNumber = Price.length

            if (LengthNumber > 3) {
                Result = ''
                for (let o of Price) {
                    ListChar.push(o)
                }
                ListChar.reverse()
                let CounterList = 0
                for (let i of ListChar) {
                    CounterList++
                    if (CounterList % 4 == 0) {
                        ListChar.splice(CounterList - 1, 0, ',')
                    }
                }
            }
            for (let C of ListChar.reverse()) {
                Result += C
            }

            P.innerText = Result
        }
    }

    //////////////////////////////      Title  Element       //////////////////////////////////////////////
    let AllTitle_ = document.querySelectorAll('[Title_]')
    for (let Element of AllTitle_) {
        let TextTitle = Element.getAttribute('Title_')

        function CreateTitleContainer() {
            let P = document.createElement('p')
            P.className = 'Title_Style_Customize'
            P.innerHTML = TextTitle
            Element.insertBefore(P, Element.firstChild)
        }

        CreateTitleContainer()
    }

    ////////////////////////////////      Create Container Blur   /////////////////////////////////////////////
    function CreateContainerBlur(Top='Default') {
        DeleteContainerBlur()
        let Container = document.createElement('div')
        let Container2 = document.createElement('div')
      //  let IconClose = document.createElement('i')
       // IconClose.onclick = DeleteContainerBlur
       // IconClose.setAttribute('id','ContainerBlurIconClose')
       // IconClose.className = 'fa fa-times ContainerBlurIconClose'
        Container.className = 'ContainerBlur'
        Container2.className = 'ContainerContentBlur p-sm-0 p-md-3'
        Top != 'Default' ? Container.style.top = Top+'%' : ''
     //   Container2.appendChild(IconClose)
        Container.appendChild(Container2)
        document.body.insertBefore(Container, document.body.firstElementChild)
        document.body.classList.add('BlurAllElementsExceptContainerBlur')
        return Container2
    }

    function DeleteContainerBlur() {
        let AllContainer = document.querySelectorAll('.ContainerBlur')
        for (let i of AllContainer) {
            i.remove()
        }
        document.body.classList.remove('BlurAllElementsExceptContainerBlur')
    }


    ////////////////     Click Out Side Container Blur And Other Container With Blur    /////////////////

    function ClickOutSideContainer(Container, FuncWhenOutSideClick) {
        let State = 'InSide'
        document.addEventListener('click', ClickOutSideCnt = function (event) {
            let IsClickInContainer = Container.contains(event.target);
            if (!IsClickInContainer) {
                if (State == 'OutSide') {
                    FuncWhenOutSideClick()
                    State = 'Inside'
                    document.removeEventListener('click',ClickOutSideCnt)
                }
                State = 'OutSide'
            }
        });
    }

    //////////////////////////////////       Trun Chate Letters   ////////////////////////////////////////////
    function TrunCateLetter(Text,ToNumber) {
        Text = String(Text)
        let LenText = Text.length
        let Y = Text.substr(0,ToNumber)
        if (parseInt(LenText) > parseInt(ToNumber)){
            Y += ' . . .'
        }
        return Y
    }


/////////////////////////////////////////////

function OpenFullscreen(elem) {
  if (elem.requestFullscreen) {
    elem.requestFullscreen();
  } else if (elem.webkitRequestFullscreen) { /* Safari */
    elem.webkitRequestFullscreen();
  } else if (elem.msRequestFullscreen) { /* IE11 */
    elem.msRequestFullscreen();
  }
}

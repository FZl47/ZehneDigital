SplitPrice()


let ContainerAboutUs = document.getElementById('ContainerAboutUs')
let ContainerContactUs = document.getElementById('ContainerContactUs')
if ($(this).scrollTop() >= $(ContainerAboutUs).position().top - ContainerAboutUs.offsetHeight) {
    ContainerAboutUs.classList.add('Show_Animation_1')
}
if ($(this).scrollTop() >= $(ContainerContactUs).position().top - ContainerContactUs.offsetHeight) {
    ContainerContactUs.classList.add('Show_Animation_1')
}
document.onscroll = function () {
    if ($(this).scrollTop() >= $(ContainerAboutUs).position().top - ContainerAboutUs.offsetHeight) {
        ContainerAboutUs.classList.add('Show_Animation_1')
    }
    if ($(this).scrollTop() >= $(ContainerContactUs).position().top - ContainerContactUs.offsetHeight) {
        ContainerContactUs.classList.add('Show_Animation_1')
    }
}


let DictStateComment = {
    'Title': false,
    'Name': false,
    'Email': false,
    'Text': false
}

function ValidationInput(Element, Input, Type) {

    let Value = Input.value
    let IconState = Element.querySelector('i')
    if (Type == 'Name') {
        if (Value != '' && Value != ' ' && Value != null && Value.trim() != '') {
            IconState.className = 'fal fa-check-circle IconStateInput'
            Input.setAttribute('State', 'Ok')
            DictStateComment['Name'] = true
        } else {
            IconState.className = 'fal fa-times-circle IconStateInput'
            Input.setAttribute('State', 'NotOk')
            DictStateComment['Name'] = false
        }
    }


    if (Type == 'Title') {
        if (Value != '' && Value != ' ' && Value != null && Value.trim() != '') {
            IconState.className = 'fal fa-check-circle IconStateInput'
            Input.setAttribute('State', 'Ok')
            DictStateComment['Title'] = true
        } else {
            IconState.className = 'fal fa-times-circle IconStateInput'
            Input.setAttribute('State', 'NotOk')
            DictStateComment['Title'] = false
        }
    }


    if (Type == 'Email') {
        if (ValidationEmail(Value) && Value.trim() != '') {
            IconState.className = 'fal fa-check-circle IconStateInput'
            Input.setAttribute('State', 'Ok')
            DictStateComment['Email'] = true

        } else {
            IconState.className = 'fal fa-times-circle IconStateInput'
            Input.setAttribute('State', 'NotOk')
            DictStateComment['Email'] = false
        }
    }
    if (Type == 'Text') {
        if (Value != '' && Value != ' ' && Value != null && Value.trim() != '') {
            IconState.className = 'fal fa-check-circle IconStateInput'
            Input.setAttribute('State', 'Ok')
            DictStateComment['Text'] = true
        } else {
            IconState.className = 'fal fa-times-circle IconStateInput'
            Input.setAttribute('State', 'NotOk')
            DictStateComment['Text'] = false
        }
    }
    StateFormSendComment()
}

function StateFormSendComment() {
    let BtnSubmit = document.querySelector('.ContainerFormSendComment [Comment_Btn]')
    if (DictStateComment['Title'] && DictStateComment['Name'] && DictStateComment['Email'] && DictStateComment['Text']) {
        BtnSubmit.className = 'Btn_Style_3 Btn_Style_Active_1'
        BtnSubmit.setAttribute('onclick', 'SubmitTicketSupport()')
    } else {
        BtnSubmit.className = 'Btn_Style_Disabled_1 Btn_Style_3'
        BtnSubmit.removeAttribute('onclick')
    }
}

function RemoveValueInputComment() {
    let Title = document.querySelector('[Comment_Title]')
    let Name = document.querySelector('[Comment_Name]')
    let Email = document.querySelector('[Comment_Email]')
    let Text = document.querySelector('[Comment_Text]')
    Title.value = null
    Name.value = null
    Email.value = null
    Text.value = null
    ResetFormComment()
}

function ResetFormComment() {
    let Title = document.querySelector('[Comment_Title]')
    let Name = document.querySelector('[Comment_Name]')
    let Email = document.querySelector('[Comment_Email]')
    let Text = document.querySelector('[Comment_Text]')
    ValidationInput(Title.parentNode, Title, 'Title')
    ValidationInput(Name.parentNode, Name, 'Name')
    ValidationInput(Email.parentNode, Email, 'Email')
    ValidationInput(Text.parentNode, Text, 'Text')
}

function ValidationEmail(Email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(Email).toLowerCase());
}

function FocusInputForm(Element) {
    Element.classList.add('ContainerInputIconActive')
}

function FocusOutInputForm(Element) {
    Element.classList.remove('ContainerInputIconActive')
}

function SubmitTicketSupport() {
    let Title = document.querySelector('[Comment_Title]').value
    let Name = document.querySelector('[Comment_Name]').value
    let Email = document.querySelector('[Comment_Email]').value
    let Text = document.querySelector('[Comment_Text]').value
    let Data = {
        'Title': Title,
        'Name': Name,
        'Email': Email,
        'Text': Text,
    }

    SendAjax('/SendTicketAdmin', Data, 'POST', function (response) {
        if (response.Status == '200') {
            ShowNotificationMessage('پیام شما با موفقیت ارسال شد', 'Success', 5000, 3)
            RemoveValueInputComment()
        } else if (response.Status == '500') {
            ShowNotificationMessage('در ثبت پیام شما مشکلی پیش امده است . مجددا تلاش کنید ', 'Error', 7000, 3)
        } else {
            ShowNotificationMessage('لطفا مجددا تلاش کنید ', 'Error', 7000, 2)
        }
    })
}
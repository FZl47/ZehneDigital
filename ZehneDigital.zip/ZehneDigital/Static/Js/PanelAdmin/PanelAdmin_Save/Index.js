 function ShowInfoArticle(ID, Title, DateCreate, TimePast, TimeRead, Views, Likes, Comments) {
            let ContainerBlur = CreateContainerBlur()
            let Node = `
                   <div class="ContainerInfoArticle">
                        <p class="IDInfoArticle"> شناسه عددی : <b>${ID}</b></p>
                        <p class="DateCreateInfoArticle">${DateCreate} (${TimePast})</p>
                        <br>
                        <p class="TitleInfoArticle">${Title}</p>
                        <br>
                        <br>
                        <div class="ViewsInfoArticle">
                            <i class="fas fa-eye"></i>
                            <p class="SplitNumber" Number="${Views}">${Views}</p>
                        </div>
                        <div class="LikesInfoArticle">
                            <i class="far fa-heart"></i>
                            <p class="SplitNumber" Number="${Likes}">${Likes}</p>
                        </div>
                        <div class="CommentsInfoArticle">
                            <i class="far fa-comment"></i>
                            <p class="SplitNumber" Number="${Comments}" >${Comments}</p>
                        </div>
                        <div class="TimeReadInfoArticle">
                            <i class="far fa-clock"></i>
                            <p>${TimeRead}</p>
                        </div>

                        <div class="text-left d-block">
                            <button class="BtnStyle_6" onclick="GoToUrl('/p/${ID}')">برو به پست</button>
                        </div>
                    </div>
            `
            ContainerBlur.innerHTML = Node
            ClickOutSideContainer(ContainerBlur, function () {
                ClearEffectOnBody()
                DeleteContainerBlur()
            })
            SplitPrice()
        }




window.onbeforeunload = function () {
    return "Data will be lost if you leave the page, are you sure?";
};
let FormSubmitObject = document.getElementById('FormSubmitObject')
let Container_Base_Node = document.getElementById('_Admin__Container__Node')
let Container_Base_Node_Editor = document.getElementById('_Admin__ContainerNode')


function PositionOnController(This, Element, TypeCall = 'Event') {
    let State = This.getAttribute('IsChecked')
    let TextBox = document.getElementById(GetInput(Element).getAttribute('TextBoxID'))
    if (TypeCall == 'Event') {
        if (State == 'false') {
            Element.classList.add('position-absolute')
            Element.querySelector('[ContainerBtnMove]').classList.remove('d-none')
            // Element.querySelector('[ContainerForMove]').classList.add('position-relative')
            TextBox.classList.add('position-absolute')
            This.setAttribute('IsChecked', 'true')
            This.setAttribute('checked', '')
        }
        if (State == 'true') {
            Element.classList.remove('position-absolute')
            Element.querySelector('[ContainerBtnMove]').classList.add('d-none')
            // Element.querySelector('[ContainerForMove]').classList.remove('position-relative')
            TextBox.classList.remove('position-absolute')
            This.setAttribute('IsChecked', 'false')
        }
    }
    if (TypeCall == 'GetInfo') {
        if (State == 'false') {
            This.removeAttribute('checked')
        }
        if (State == 'true') {
            This.setAttribute('checked', '')
        }
    }
}


function SetSizeImageTiming(Element, Type) {
    try {
        clearInterval(TimerSetSize)
    } catch (e) {
    }
    let TimerSetSize
    TimerSetSize = setInterval(
        function () {
            let StateActiveBtn = Element.querySelector('button:active')
            if (StateActiveBtn != null) {
                SetSizeImage(Element, Type)
            } else {
                clearInterval(TimerSetSize)
            }
        }, 10)
}

function SetSizeImage(Element, Type) {
    let Image = Element.querySelector('[Image]')
    let TextBox = document.getElementById(GetInput(Element).getAttribute('TextBoxID'))

    if (Image.getAttribute('Unit') == 'Percentage') {
        let ElementWidth = parseInt(Element.style.width.split('%')[0])
        let ElementHeight = parseInt(Element.style.height.split('%')[0])

        //Element.querySelector('[WidthImage]').innerHTML = WidthImage + '%'
        //Element.querySelector('[heightImage]').innerHTML = HeightImage + '%'

        if (isNaN(ElementWidth)) {
            ElementWidth = window.getComputedStyle(Element).width.split('px')[0]
        }
        if (isNaN(ElementHeight)) {
            ElementHeight = window.getComputedStyle(Element).height.split('px')[0]
        }

        // if (ElementWidth > 100) {
        //     ElementHeight = 100
        //}


        if (Type == 'Height_Increase') {
            ElementHeight += 1
            Element.style.height = ElementHeight + 'px'
            TextBox.style.height = ElementHeight + 'px'
            Element.setAttribute('HeightSeted', ElementHeight)
        }
        if (Type == 'Height_Decrease') {
            ElementHeight -= 1
            Element.style.height = ElementHeight + 'px'
            TextBox.style.height = ElementHeight + 'px'
            Element.setAttribute('HeightSeted', ElementHeight)

        }
        if (Type == 'Width_Increase') {
            ElementWidth += 1
            Element.style.width = ElementWidth + '%'
            TextBox.style.width = ElementWidth + '%'
            Element.setAttribute('WidthSeted', ElementWidth)
        }
        if (Type == 'Width_Decrease') {
            ElementWidth -= 1
            Element.style.width = ElementWidth + '%'
            TextBox.style.width = ElementWidth + '%'
            Element.setAttribute('WidthSeted', ElementWidth)
        }


    } else {
        let ElementWidth = parseInt(Element.style.width.split('%')[0])
        let ElementHeight = parseInt(Element.style.height.split('%')[0])

        if (isNaN(ElementWidth)) {
            ElementWidth = window.getComputedStyle(Element).width.split('px')[0]
        }
        if (isNaN(ElementHeight)) {
            ElementHeight = window.getComputedStyle(Element).height.split('px')[0]
        }

        // Element.querySelector('[WidthImage]').innerHTML = WidthImage + 'px'
        // Element.querySelector('[heightImage]').innerHTML = HeightImage + 'px'
        if (Type == 'Height_Increase') {
            Element.style.height = ElementHeight + 2 + 'px'
            TextBox.style.height = ElementHeight + 2 + 'px'
        }
        if (Type == 'Height_Decrease') {
            Element.style.height = ElementHeight - 2 + 'px'
            TextBox.style.height = ElementHeight - 2 + 'px'
        }
        if (Type == 'Width_Increase') {
            Element.style.width = ElementWidth + 2 + 'px'
            TextBox.style.width = ElementWidth + 2 + 'px'
        }
        if (Type == 'Width_Decrease') {
            Element.style.width = ElementWidth - 2 + 'px'
            TextBox.style.width = ElementWidth - 2 + 'px'
        }
    }


}

function SetUnitSizeImage(This, Element) {
    Element.querySelector('[Image]').setAttribute('Unit', This.value)
}

let CounterImageFormSubmit = 0

function LoadImage(Event, This, Element) {
    let TextBox = document.getElementById(This.getAttribute('TextBoxID'))
    let Image = Element.querySelector('[Image]')
    let SrcImgUploaded = URL.createObjectURL(Event.target.files[0]);
    let InputImage = Element.querySelector('[InputImage]')
    Image.src = SrcImgUploaded
    Image.setAttribute('TextBoxID', This.getAttribute('TextBoxID'))
    Image.setAttribute('Src_Past', SrcImgUploaded)
    TextBox.src = SrcImgUploaded
    TextBox.setAttribute('Src_Past', SrcImgUploaded)
    SetInputImageToForm(InputImage, Element)

    Image.onload = function () {
        Image.classList.remove('d-none')
        This.classList.add('d-none')
        Element.querySelector('[ContainerBtnsResizeImage_V]').classList.remove('d-none')
        Element.querySelector('[ContainerBtnsResizeImage_H]').classList.remove('d-none')
    }

};


function SetInputImageToForm(InputImage, Element) {

    InputImage.classList.add('d-none')
    CounterImageFormSubmit++
    let Image = Element.querySelector('[Image]')
    Image.classList.remove('d-none')

    InputImage.name = `Image_${CounterImageFormSubmit}`
    let InputForForm = $(InputImage).clone()
    InputForForm.removeAttr('InputText')
    InputForForm.removeAttr('InputImage')
    InputForForm.appendTo(FormSubmitObject)
}


function SetSizeInControllerTiming(Element, Type) {
    try {
        clearInterval(TimerSetSizeController)
    } catch (e) {
    }
    let TimerSetSizeController
    TimerSetSizeController = setInterval(
        function () {
            let StateActiveBtn = Element.querySelector('button:active')
            if (StateActiveBtn != null) {
                SetSizeController(Element, Type)
            } else {
                clearInterval(TimerSetSizeController)
            }
        }, 10)
}


function SetSizeController(Element, Type) {
    let WidthElement = parseInt(String(Element.style.width).split('%')[0])
    if (isNaN(WidthElement)) {
        WidthElement = parseInt(window.getComputedStyle(Element).width.split('px')[0])
        if (WidthElement >= 99) {
            WidthElement = 100
        }
    }
    let HeightElement = parseInt(window.getComputedStyle(Element).height.split('px')[0])
    let TextBox = document.getElementById(GetInput(Element).getAttribute('TextBoxID'))

    if (Type == 'Height_Increase') {
        HeightElement += 3
        SetHeightInput()
        SetHeightController()
    }
    if (Type == 'Height_Decrease') {
        HeightElement -= 3
        SetHeightInput()
        SetHeightController()
    }
    if (Type == 'Width_Increase') {
        if (WidthElement <= 99) {
            WidthElement++
        }
        SetWidthController()
    }
    if (Type == 'Width_Decrease') {
        if (WidthElement >= 0) {
            WidthElement--
        }
        SetWidthController()
    }

    function SetHeightInput() {
        let TypeController = Element.getAttribute('ControllerText')
        if (TypeController != null && TypeController != undefined) {
            let Input = GetInput(Element)
            Input.style.height = HeightElement + -43 + 'px'
        }
    }

    function SetHeightController() {
        Element.style.height = HeightElement + 'px'
        TextBox.style.height = HeightElement + 'px'
        Element.setAttribute('HeightSeted', HeightElement)
    }

    function SetWidthController() {
        Element.style.width = WidthElement + '%'
        TextBox.style.width = WidthElement + '%'
        Element.setAttribute('WidthSeted', WidthElement)
    }

}


function SetSizeContainerTiming(This, Element, Type) {
    try {
        clearInterval(TimerSetSize)
    } catch (e) {
    }
    let TimerSetSize
    TimerSetSize = setInterval(
        function () {
            let StateActiveBtn = Element.querySelector('button:active')
            if (StateActiveBtn != null) {
                SetSizeContainer(This, Element, Type)
            } else {
                clearInterval(TimerSetSize)
            }
        }, 10)
}

function SetSizeContainer(This, Element, Type) {
    let Container_Edit = document.getElementById('_Admin__ContainerNode')
    let Container_Node = document.getElementById('_Admin__Container__Node')


    let HeightContainer = parseInt(window.getComputedStyle(Container_Edit).height.split('px')[0])
    let WidthContainer = parseInt(window.getComputedStyle(Container_Edit).width.split('px')[0])
    if (Type == 'Height_Increase') {
        Container_Edit.style.height = HeightContainer + 2 + 'px'
        Container_Node.style.height = HeightContainer + 2 + 'px'
    }
    if (Type == 'Height_Decrease') {
        Container_Edit.style.height = HeightContainer - 2 + 'px'
        Container_Node.style.height = HeightContainer - 2 + 'px'
    }
    if (Type == 'Width_Increase') {
        Container_Edit.style.width = WidthContainer + 2 + 'px'
        Container_Node.style.width = WidthContainer + 2 + 'px'
    }
    if (Type == 'Width_Decrease') {
        Container_Edit.style.width = WidthContainer - 2 + 'px'
        Container_Node.style.width = WidthContainer - 2 + 'px'
    }

}


function GetInput(Element) {
    return Element.querySelector('[inputText]')
}

function GetControllersText() {
    return document.querySelectorAll('[ControllerText]')
}

function GetControllers() {
    return document.querySelectorAll('[Controller]')
}

let ListCreatedController = []
let ListUniqueID = []

function CreateUniqueID() {
    let Number = CreateRandomNumber()
    ListUniqueID.push(Number)
    return Number
}


function CreateRandomNumber() {
    return Math.floor(Math.random() * 999999999999999)
}


function LoadDataController(TextBoxID, Type) {
    let TextBox = document.querySelector(`[TextBoxID=${TextBoxID}]`)
    let Controller = TextBox.parentNode.parentNode.parentNode
    if (Type == 'Title' || Type == 'Text' || Type == 'Link') {
        let Bold_I = Controller.querySelector('[InputBold]')
        let Italic_I = Controller.querySelector('[InputItalic]')
        let FontSize_I = Controller.querySelector('[InputFontSize]')
        let Mt_I = Controller.querySelector('[Mt]')
        let Mb_I = Controller.querySelector('[Mb]')
        let Mr_I = Controller.querySelector('[Mr]')
        let Ml_I = Controller.querySelector('[Ml]')
        let Color_I = Controller.querySelector('[InputColor]')
        let Center_I = Controller.querySelector('[CenterController]')
        let TextAlign_I = Controller.querySelector('[TextAlign]')
        let Position_I = Controller.querySelector('[PositionAbsolute]')

        BoldText(Bold_I, Controller)
        ItalicText(Italic_I, Controller)
        FontSize(FontSize_I, Controller)
        MarginOnController(Mt_I, Controller, 'Top')
        MarginOnController(Mb_I, Controller, 'Bottom')
        MarginOnController(Mr_I, Controller, 'Right')
        MarginOnController(Ml_I, Controller, 'Left')
        ColorText(Color_I, Controller)
        ControllerCenter(Center_I, Controller)
        TextAlignController(TextAlign_I, Controller)
        PositionOnController(Position_I, Controller)
    }
    if (Type == 'Image') {

        let Mt_I = Controller.querySelector('[Mt]')
        let Mb_I = Controller.querySelector('[Mb]')
        let Mr_I = Controller.querySelector('[Mr]')
        let Ml_I = Controller.querySelector('[Ml]')
        let Center_I = Controller.querySelector('[CenterController]')
        let TextAlign_I = Controller.querySelector('[TextAlign]')
        let Position_I = Controller.querySelector('[PositionAbsolute]')


        let Image_I = Controller.querySelector('[InputImageController]')
        Image_I.classList.remove('d-none')
        TextBox.classList.add('d-none')

        let ImageNode = document.getElementById(TextBoxID)
        ImageNode.src = Image_I.src
        ImageNode.setAttribute('Src_Past', Image_I.src)


        MarginOnController(Mt_I, Controller, 'Top')
        MarginOnController(Mb_I, Controller, 'Bottom')
        MarginOnController(Mr_I, Controller, 'Right')
        MarginOnController(Ml_I, Controller, 'Left')
        ControllerCenter(Center_I, Controller)
        TextAlignController(TextAlign_I, Controller)
        PositionOnController(Position_I, Controller)
    }

}


function CreateTitle(TextBoxID = 'Default', Text = '', Bold = false, Italic = false, FontSize = 21, Mt = 0, Mb = 0, Mr = 0, Ml = 0, Color = null, Center = false, TextAlign = false, Position = false, Top = -47, Right = 0, Width = 22, Height = 'Auto', State = 'Default') {

    //------------------------   Show Container Base   ------------------------------------//
    Container_Base_Node.classList.remove('d-none')
    Container_Base_Node_Editor.classList.remove('d-none')
    //-------------------------------------------------------------------------------------//
    let ContainerNode_Edit = document.getElementById('_Admin__ContainerNode')
    let _ContainerNode_ = document.getElementById('_Admin__Container__Node')
    let ID_Unique = CreateUniqueID()
    let ID_UniqueWithName = `TextBox_${ID_Unique}`
    if (State == 'Geted') {
        ID_UniqueWithName = TextBoxID
        Bold = ReverceBoolean(Bold)
        Italic = ReverceBoolean(Italic)
        Center = ReverceBoolean(Center)
        TextAlign = ReverceBoolean(TextAlign)
        Position = ReverceBoolean(Position)
        if (Color == 'None'){
            Color = ''
        }else {
            Color = `value=${Color}`
        }
    }

    let Node_Edit = `
            <div class="ContainerTitle_Added" style="width: ${Width}%;height: ${Height};right: ${Right}px;top: ${Top}px" Controller ControllerText TypeController="Title" WidthSeted="${Width}" HeightSeted="${Height}"
             onmouseover="OnControllerAndFocus(this)"
            >
            <div class="ContainerForMove" ContainerForMove>
                <div class="ContainerToolsText">
                    <i class="fal fa-bars IconShowMenuTools"></i>
                    <div class="MenuItemTools">
                        <p class="LabelItemTools">بولد</p>
                        <div class="ToolsItem_Text"
                             onclick="BoldText(this,this.parentNode.parentNode.parentNode.parentNode)"
                             State="${Bold}" InputBold>
                            <i class="fa fa-bold"></i>
                        </div>
                        <br>
                        <p class="LabelItemTools">کج</p>
                        <div class="ToolsItem_Text"
                             onclick="ItalicText(this,this.parentNode.parentNode.parentNode.parentNode)"
                             State="${Italic}" InputItalic>
                            <i class="fa fa-italic"></i>
                        </div>
                        <br>
                        <p class="LabelItemTools">سایز فونت </p>
                        <input type="number" class="ToolsItem_Text" min="0" value="${FontSize}"
                               onchange="FontSize(this,this.parentNode.parentNode.parentNode.parentNode)" InputFontSize>
                        <br>
                        <p class="LabelItemTools">فاصله از بالا</p>
                        <input class="ToolsItem_Text" type="number" value="${Mt}" ValueSeted="${Mt}" Mt onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Top')">
                        <br>
                        <p class="LabelItemTools">فاصله از پایین</p>
                        <input class="ToolsItem_Text" type="number" value="${Mb}" ValueSeted="${Mb}" Mb  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Bottom')" >
                        <br>
                        <p class="LabelItemTools">فاصله از راست</p>
                        <input class="ToolsItem_Text" type="number" value="${Mr}" ValueSeted="${Mr}" Mr  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Right')" >
                        <br>
                        <p class="LabelItemTools">فاصله از چپ</p>
                        <input class="ToolsItem_Text" type="number" value="${Ml}" ValueSeted="${Ml}" Ml  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Left')" >
                        <br>
                        <p class="LabelItemTools">رنگ</p>
                         <input type="color" ${Color} onchange="ColorText(this,this.parentNode.parentNode.parentNode.parentNode)"
                               InputColor
                               title="رنگ" class="ToolsItem_Text" >
                         <br>
                         <p class="LabelItemTools">وسط چین</p>
                         <input type="checkbox" IsChecked=${Center} CenterController onchange="ControllerCenter(this,this.parentNode.parentNode.parentNode.parentNode)">
                         <br>
                         <p class="LabelItemTools">  وسط چین متن </p>
                         <input type="checkbox" IsChecked=${TextAlign} TextAlign onchange="TextAlignController(this,this.parentNode.parentNode.parentNode.parentNode)">
                         <br>
                        <p class="LabelItemTools">چیدمان ازاد</p>
                        <input type="checkbox" IsChecked=${Position} PositionAbsolute onchange="PositionOnController(this,this.parentNode.parentNode.parentNode.parentNode)">
                    </div>

                    <div class="Btn_ResizeContainer_H">
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Height_Increase')" InputHeightIncrease>
                            <i class="fa fa-arrow-from-top" ></i>
                        </button>
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Height_Decrease')" InputHeightDecrase>
                            <i class="fa fa-arrow-from-bottom " ></i>
                        </button>
                    </div>
                    <div class="Btn_ResizeContainer_V">
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Width_Increase')" InputWidthIncrease>
                            <i class="fa fa-arrow-from-right "></i>
                        </button>

                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Width_Decrease')" InputWidthDecrase>
                            <i class="fa fa-arrow-from-left "></i>
                        </button>
                    </div>
                    <i class="fa fa-trash ToolsItem_Text float-left"
                       onclick="DeleteContainer_Added(this.parentNode.parentNode.parentNode,'Title')"></i>
                </div>
                <div>
                    <input type="text" placeholder="عنوان خود را وارد کنید" class="InputTextAdded" InputText InputTitle
                           TextBoxID=${ID_UniqueWithName} onchange="SetTextInput(this)" value="${Text}">
                    <input type="hidden" class="ContainerTitle_Added_Info">
                </div>
                <div class="ContainerBtnMove d-none " Right="${Right}" Top="${Top}" ContainerBtnMove>
                    <button class="Btn_Move_Container_Top"
                            onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Top')" InputLocationTop>
                        <i class="fa fa-arrow-up"></i>
                    </button>
                    <button class="Btn_Move_Container_Right"
                            onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Right')" InputLocationRight>
                        <i class="fa fa-arrow-right"></i>
                    </button>
                    <button class="Btn_Move_Container_Bottom"
                            onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Bottom')" InputLocationBottom>
                        <i class="fa fa-arrow-down"></i>
                    </button>
                    <button class="Btn_Move_Container_Left"
                            onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Left')" InputLocationLeft>
                        <i class="fa fa-arrow-left"></i>
                    </button>
                </div>
            </div>
        </div>
`


    let _Node_ = `
                <p class='_Admin__TextBox_Title' style='22%'  id='${ID_UniqueWithName}'></p>
            `


    ContainerNode_Edit.innerHTML += Node_Edit
    if (State == 'Default') {
        _ContainerNode_.innerHTML += _Node_
        let DictController = {}
        DictController['TypeController'] = 'Title'
        DictController['TextBoxID'] = String(`${ID_UniqueWithName}`)
        ListCreatedController.push(JSON.stringify(DictController))
    }

    BackValueToInput()


}

function CreateText(TextBoxID = 'Default', Text = '', Bold = false, Italic = false, FontSize = 16, Mt = 0, Mb = 0, Mr = 0, Ml = 0, Color = null, Center = false, TextAlign = false, Position = false, Top = -47, Right = 0, Width = 22, Height = 'Auto', State = 'Default') {
    //------------------------   Show Container Base   ------------------------------------//
    Container_Base_Node.classList.remove('d-none')
    Container_Base_Node_Editor.classList.remove('d-none')
    //-------------------------------------------------------------------------------------//
    let ContainerNode_Edit = document.getElementById('_Admin__ContainerNode')
    let _ContainerNode_ = document.getElementById('_Admin__Container__Node')
    let ID_Unique = CreateUniqueID()
    let ID_UniqueWithName = `TextBox_${ID_Unique}`
    if (State == 'Geted') {
        ID_UniqueWithName = TextBoxID
        Bold = ReverceBoolean(Bold)
        Italic = ReverceBoolean(Italic)
        Center = ReverceBoolean(Center)
        TextAlign = ReverceBoolean(TextAlign)
        Position = ReverceBoolean(Position)
        if (Color == 'None'){
            Color = ''
        }else {
            Color = `value=${Color}`
        }
    }
    let Node_Edit = `<div class="ContainerText_Added" style="width: ${Width}%;height: ${Height}px;right: ${Right}px;top: ${Top}px" Controller ControllerText TypeController="Text" WidthSeted="${Width}" HeightSeted="${Height}" onmouseover="OnControllerAndFocus(this)" >
                <div class="ContainerForMove" ContainerForMove>
                     <div class="ContainerToolsText">
                    <i class="fal fa-bars IconShowMenuTools"></i>
                    <div class="MenuItemTools">
                        <p class="LabelItemTools">بولد</p>
                        <div class="ToolsItem_Text"
                             onclick="BoldText(this,this.parentNode.parentNode.parentNode.parentNode)"
                             State="${Bold}" InputBold>
                            <i class="fa fa-bold"></i>
                        </div>
                        <br>
                        <p class="LabelItemTools">کج</p>
                        <div class="ToolsItem_Text"
                             onclick="ItalicText(this,this.parentNode.parentNode.parentNode.parentNode)"
                             State="${Italic}" InputItalic>
                            <i class="fa fa-italic"></i>
                        </div>
                        <br>
                        <p class="LabelItemTools">سایز فونت </p>
                        <input type="number" class="ToolsItem_Text" min="0" value="${FontSize}"
                               onchange="FontSize(this,this.parentNode.parentNode.parentNode.parentNode)" InputFontSize >
                        <br>
                         <p class="LabelItemTools">فاصله از بالا</p>
                        <input class="ToolsItem_Text" type="number" value="${Mt}" ValueSeted="${Mt}" Mt onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Top')">
                        <br>
                        <p class="LabelItemTools">فاصله از پایین</p>
                        <input class="ToolsItem_Text" type="number" value="${Mb}" ValueSeted="${Mb}" Mb  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Bottom')" >
                        <br>
                        <p class="LabelItemTools">فاصله از راست</p>
                        <input class="ToolsItem_Text" type="number" value="${Mr}" ValueSeted="${Mr}" Mr  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Right')" >
                        <br>
                        <p class="LabelItemTools">فاصله از چپ</p>
                        <input class="ToolsItem_Text" type="number" value="${Ml}" ValueSeted="${Ml}" Ml  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Left')" >
                        <br>
                        <p class="LabelItemTools">رنگ</p>
                        <input type="color" ${Color} onchange="ColorText(this,this.parentNode.parentNode.parentNode.parentNode)"
                               InputColor
                               title="رنگ" class="ToolsItem_Text">
                        <br>
                         <p class="LabelItemTools">وسط چین</p>
                         <input type="checkbox" IsChecked=${Center} CenterController onchange="ControllerCenter(this,this.parentNode.parentNode.parentNode.parentNode)">
                         <br>
                         <p class="LabelItemTools">  وسط چین متن </p>
                         <input type="checkbox" IsChecked=${TextAlign} TextAlign onchange="TextAlignController(this,this.parentNode.parentNode.parentNode.parentNode)">
                         <br>
                        <p class="LabelItemTools">چیدمان ازاد</p>
                        <input type="checkbox" IsChecked=${Position} PositionAbsolute onchange="PositionOnController(this,this.parentNode.parentNode.parentNode.parentNode)">
                    </div>

                    <div class="Btn_ResizeContainer_H">
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Height_Increase')">
                            <i class="fa fa-arrow-from-top"></i>
                        </button>
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Height_Decrease')">
                            <i class="fa fa-arrow-from-bottom "></i>
                        </button>
                    </div>
                    <div class="Btn_ResizeContainer_V">
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Width_Increase')">
                            <i class="fa fa-arrow-from-right "></i>
                        </button>

                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Width_Decrease')">
                            <i class="fa fa-arrow-from-left "></i>
                        </button>
                    </div>
                    <i class="fa fa-trash ToolsItem_Text float-left"
                       onclick="DeleteContainer_Added(this.parentNode.parentNode.parentNode,'Text')"></i>
                </div>
                    <div>
                        <textarea contenteditable="true" cols="40" placeholder="متن خود را وارد کنید"
                                  class="InputTextAdded" InputText TextBoxID=${ID_UniqueWithName}
                                  onchange="SetTextInput(this)" >${Text}</textarea>
                        <input type="hidden" class="ContainerTitle_Added_Info">
                    </div>
                    <div class="ContainerBtnMove d-none" Right="${Right}" Top="${Top}" ContainerBtnMove>
                        <button class="Btn_Move_Container_Top"
                                onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Top')">
                            <i class="fa fa-arrow-up"></i>
                        </button>
                        <button class="Btn_Move_Container_Right"
                                onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Right')">
                            <i class="fa fa-arrow-right"></i>
                        </button>
                        <button class="Btn_Move_Container_Bottom"
                                onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Bottom')">
                            <i class="fa fa-arrow-down"></i>
                        </button>
                        <button class="Btn_Move_Container_Left"
                                onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Left')">
                            <i class="fa fa-arrow-left"></i>
                        </button>
                    </div>

                </div>
            </div>`

    let _Node_ = `
                <p class='_Admin__TextBox_Text' id='${ID_UniqueWithName}' ></p>
            `

    ContainerNode_Edit.innerHTML += Node_Edit
    if (State == 'Default') {
        _ContainerNode_.innerHTML += _Node_
        let DictController = {}
        DictController['TypeController'] = 'Text'
        DictController['TextBoxID'] = String(`${ID_UniqueWithName}`)
        ListCreatedController.push(JSON.stringify(DictController))
    }


    BackValueToInput()
}

function CreateImage(TextBoxID = 'Default', Src = 'None', Mt = 0, Mb = 0, Mr = 0, Ml = 0, Center = false, TextAlign = false, Position = false, Top = -47, Right = 0, Width = 20, Height = 14, State = 'Default') {
    //------------------------   Show Container Base   ------------------------------------//
    Container_Base_Node.classList.remove('d-none')
    Container_Base_Node_Editor.classList.remove('d-none')
    //-------------------------------------------------------------------------------------//
    let ContainerNode_Edit = document.getElementById('_Admin__ContainerNode')
    let _ContainerNode_ = document.getElementById('_Admin__Container__Node')
    let ArticleTitle = document.getElementById('InformationArticle').getAttribute('ArticleTitle')
    let ID_Unique = CreateUniqueID()
    let ID_UniqueWithName = `TextBox_${ID_Unique}`
    if (State == 'Geted') {
        ID_UniqueWithName = TextBoxID
        Center = ReverceBoolean(Center)
        TextAlign = ReverceBoolean(TextAlign)
        Position = ReverceBoolean(Position)
    }
    let Node_Edit =
        `        <div class="ContainerImage_Added" Controller ControllerImage style="width:${Width}%;height:${Height}%;right: ${Right}px;top: ${Top}px"  WidthSeted="${Width}" HeightSeted="${Height}"  onmouseover="OnControllerAndFocus(this)" >
            <div class="ContainerForMove" ContainerForMove>
                 <div class="ContainerToolsText">
                    <i class="fal fa-bars IconShowMenuTools"></i>
                    <div class="MenuItemTools">
                         <p class="LabelItemTools">فاصله از بالا</p>
                        <input class="ToolsItem_Text" type="number" value="${Mt}" ValueSeted="${Mt}" Mt onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Top')">
                        <br>
                        <p class="LabelItemTools">فاصله از پایین</p>
                        <input class="ToolsItem_Text" type="number" value="${Mb}" ValueSeted="${Mb}" Mb onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Bottom')" >
                        <br>
                        <p class="LabelItemTools">فاصله از راست</p>
                        <input class="ToolsItem_Text" type="number" value="${Mr}" ValueSeted="${Mr}" Mr  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Right')" >
                        <br>
                        <p class="LabelItemTools">فاصله از چپ</p>
                        <input class="ToolsItem_Text" type="number" value="${Ml}" ValueSeted="${Ml}" Ml onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Left')" >
                        <br>
                        <p class="LabelItemTools">وسط چین</p>
                         <input type="checkbox" IsChecked=${Center} CenterController onchange="ControllerCenter(this,this.parentNode.parentNode.parentNode.parentNode)">
                         <br>
                         <p class="LabelItemTools">  وسط چین متن </p>
                         <input type="checkbox" IsChecked=${TextAlign} TextAlign onchange="TextAlignController(this,this.parentNode.parentNode.parentNode.parentNode)">
                         <br>
                        <p class="LabelItemTools">چیدمان ازاد</p>
                        <input type="checkbox" IsChecked=${Position} PositionAbsolute onchange="PositionOnController(this,this.parentNode.parentNode.parentNode.parentNode)">
                    </div>

                    <div class="Btn_ResizeContainer_H" ContainerBtnsResizeImage_H>
                        <button onmousedown="SetSizeImageTiming(this.parentNode.parentNode.parentNode.parentNode,'Height_Increase')">
                            <i class="fa fa-arrow-from-top"></i>
                        </button>
                        <button onmousedown="SetSizeImageTiming(this.parentNode.parentNode.parentNode.parentNode,'Height_Decrease')">
                            <i class="fa fa-arrow-from-bottom "></i>
                        </button>
                    </div>
                    <div class="Btn_ResizeContainer_V" ContainerBtnsResizeImage_V>
                        <button onmousedown="SetSizeImageTiming(this.parentNode.parentNode.parentNode.parentNode,'Width_Increase')">
                            <i class="fa fa-arrow-from-right "></i>
                        </button>

                        <button onmousedown="SetSizeImageTiming(this.parentNode.parentNode.parentNode.parentNode,'Width_Decrease')">
                            <i class="fa fa-arrow-from-left "></i>
                        </button>
                    </div>
                    <i class="fa fa-trash ToolsItem_Text float-left"
                       onclick="DeleteContainer_Added(this.parentNode.parentNode.parentNode,'Image')"></i>
                </div>
                <div>
                    <input type="file" accept="image/*" class="InputTextAdded"
                           InputImage InputText TextBoxID=${ID_UniqueWithName}
                           onchange="LoadImage(event,this,this.parentNode.parentNode.parentNode);SetTextInput(this)" value="_Geted__" enctype="multipart/form-data">
                    <img src="${Src}" Src_Past="${Src}" alt="${ArticleTitle}" title="${ArticleTitle}" class="d-none"
                         style="width: 100%;height: 100%" Image Unit="Percentage" InputImageController   >
                    <input type="hidden" class="ContainerTitle_Added_Info">
                </div>
                <div class="ContainerBtnMove d-none" Right="${Right}" Top="${Top}" ContainerBtnMove >
                    <button class="Btn_Move_Container_Top"
                            onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Top')">
                        <i class="fa fa-arrow-up"></i>
                    </button>
                    <button class="Btn_Move_Container_Right"
                            onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Right')">
                        <i class="fa fa-arrow-right"></i>
                    </button>
                    <button class="Btn_Move_Container_Bottom"
                            onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Bottom')">
                        <i class="fa fa-arrow-down"></i>
                    </button>
                    <button class="Btn_Move_Container_Left"
                            onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Left')">
                        <i class="fa fa-arrow-left"></i>
                    </button>
                </div>
            </div>
        </div>`
    let _Node_ = `
                <img class='_Admin__TextBox_Img' loading="lazy" style="width: 20%;height: 14%" alt="${ArticleTitle}" title="${ArticleTitle}" id='${ID_UniqueWithName}'  >
            `

    ContainerNode_Edit.innerHTML += Node_Edit
    if (State == 'Default') {
        _ContainerNode_.innerHTML += _Node_
        let DictController = {}
        DictController['TypeController'] = 'Image'
        DictController['TextBoxID'] = String(`${ID_UniqueWithName}`)
        ListCreatedController.push(JSON.stringify(DictController))
    }
    if (State == 'Geted') {
        let ImageInput = ContainerNode_Edit.querySelector(`[TextBoxID=${ID_UniqueWithName}]`)
        LoadDataController(TextBoxID, 'Image')
        SetInputImageToForm(ImageInput, ImageInput.parentNode.parentNode.parentNode)
    }


    BackValueToInput()
}


function CreateLink(StateSelect, TextBoxID = 'Default', Text = '', Href = '', Bold = false, Italic = false, FontSize = 16, Mt = 0, Mb = 0, Mr = 0, Ml = 0, Color = null, Center = false, TextAlign = false, Position = false, Top = -47, Right = 0, Width = 22, Height = 'Auto', State = 'Default') {
    //------------------------   Show Container Base   ------------------------------------//
    Container_Base_Node.classList.remove('d-none')
    Container_Base_Node_Editor.classList.remove('d-none')
    //-------------------------------------------------------------------------------------//
    if (StateSelect == 'NotSelect') {
        let ContainerNode_Edit = document.getElementById('_Admin__ContainerNode')
        let _ContainerNode_ = document.getElementById('_Admin__Container__Node')
        let ID_Unique = CreateUniqueID()
        let ID_UniqueWithName = `TextBox_${ID_Unique}`
        if (State == 'Geted') {
            ID_UniqueWithName = TextBoxID
            Bold = ReverceBoolean(Bold)
            Italic = ReverceBoolean(Italic)
            Center = ReverceBoolean(Center)
            TextAlign = ReverceBoolean(TextAlign)
            Position = ReverceBoolean(Position)
        }

        let Node_Edit = `
            <div class="ContainerLink_Added" Controller ControllerText style="width:${Width}%;height:${Height}%;right: ${Right}px;top: ${Top}px"  WidthSeted="${Width}" HeightSeted="${Height}" TypeController="Link" onmouseover="OnControllerAndFocus(this)" >
                <div class="ContainerForMove" ContainerForMove>
                    <div class="ContainerToolsText">
                    <i class="fal fa-bars IconShowMenuTools"></i>
                    <div class="MenuItemTools">
                        <p class="LabelItemTools">بولد</p>
                        <div class="ToolsItem_Text"
                             onclick="BoldText(this,this.parentNode.parentNode.parentNode.parentNode)"
                             State="${Bold}" InputBold>
                            <i class="fa fa-bold"></i>
                        </div>
                        <br>
                        <p class="LabelItemTools">کج</p>
                        <div class="ToolsItem_Text"
                             onclick="ItalicText(this,this.parentNode.parentNode.parentNode.parentNode)"
                             State="${Italic}" InputItalic>
                            <i class="fa fa-italic"></i>
                        </div>
                        <br>
                        <p class="LabelItemTools">سایز فونت </p>
                        <input type="number" class="ToolsItem_Text" min="0" value="${FontSize}"
                               onchange="FontSize(this,this.parentNode.parentNode.parentNode.parentNode)" InputFontSize>
                        <br>
                         <p class="LabelItemTools">فاصله از بالا</p>
                        <input class="ToolsItem_Text" type="number" value="${Mt}" ValueSeted="${Mt}" Mt onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Top')">
                        <br>
                        <p class="LabelItemTools">فاصله از پایین</p>
                        <input class="ToolsItem_Text" type="number" value="${Mb}" ValueSeted="${Mb}" Mb  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Bottom')" >
                        <br>
                        <p class="LabelItemTools">فاصله از راست</p>
                        <input class="ToolsItem_Text" type="number" value="${Mr}" ValueSeted="${Mr}" Mr  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Right')" >
                        <br>
                        <p class="LabelItemTools">فاصله از چپ</p>
                        <input class="ToolsItem_Text" type="number" value="${Ml}" ValueSeted="${Ml}" Ml  onchange="MarginOnController(this,this.parentNode.parentNode.parentNode.parentNode,'Left')" >
                        <br>
                        <p class="LabelItemTools">رنگ</p>
                        <input type="color" value="${Color}" onchange="ColorText(this,this.parentNode.parentNode.parentNode.parentNode)"
                               InputColor
                               title="رنگ" class="ToolsItem_Text">
                        <br>
                        <p class="LabelItemTools">وسط چین</p>
                         <input type="checkbox" IsChecked=${Center} CenterController onchange="ControllerCenter(this,this.parentNode.parentNode.parentNode.parentNode)">
                         <br>
                         <p class="LabelItemTools">  وسط چین متن </p>
                         <input type="checkbox" IsChecked=${TextAlign} TextAlign onchange="TextAlignController(this,this.parentNode.parentNode.parentNode.parentNode)">
                         <br>
                        <p class="LabelItemTools">چیدمان ازاد</p>
                        <input type="checkbox" IsChecked=${Position} PositionAbsolute onchange="PositionOnController(this,this.parentNode.parentNode.parentNode.parentNode)">
                    </div>

                    <div class="Btn_ResizeContainer_H">
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Height_Increase')">
                            <i class="fa fa-arrow-from-top"></i>
                        </button>
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Height_Decrease')">
                            <i class="fa fa-arrow-from-bottom "></i>
                        </button>
                    </div>
                    <div class="Btn_ResizeContainer_V">
                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Width_Increase')">
                            <i class="fa fa-arrow-from-right "></i>
                        </button>

                        <button onmousedown="SetSizeInControllerTiming(this.parentNode.parentNode.parentNode.parentNode,'Width_Decrease')">
                            <i class="fa fa-arrow-from-left "></i>
                        </button>
                    </div>
                    <i class="fa fa-trash ToolsItem_Text float-left"
                       onclick="DeleteContainer_Added(this.parentNode.parentNode.parentNode,'Link')"></i>
                </div>
                    <div>
                        <input type="text" placeholder="متن لینک خود را وارد کنید" value="${Text}" class="InputTextAdded" InputText TextBoxID=${ID_UniqueWithName} onchange="SetTextInput(this)" >
                        <br>
                        <input type="text" placeholder="آدرس لینک خود را وارد کنید" value="${Href}" class="InputTextAdded" InputLink onchange="SetAddressLink(this,this.parentNode.parentNode.parentNode)">
                        <input type="hidden" class="ContainerTitle_Added_Info">
                    </div>
                    <div class="ContainerBtnMove d-none" Right="${Right}" Top="${Top}" ContainerBtnMove>
                        <button class="Btn_Move_Container_Top"
                                onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Top')">
                            <i class="fa fa-arrow-up"></i>
                        </button>
                        <button class="Btn_Move_Container_Right"
                                onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Right')">
                            <i class="fa fa-arrow-right"></i>
                        </button>
                        <button class="Btn_Move_Container_Bottom"
                                onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Bottom')">
                            <i class="fa fa-arrow-down"></i>
                        </button>
                        <button class="Btn_Move_Container_Left"
                                onmousedown="SetLocation(this,this.parentNode,this.parentNode.parentNode.parentNode,'Left')">
                            <i class="fa fa-arrow-left"></i>
                        </button>
                    </div>
                </div>
            </div>`


        let _Node_ = `
                <a class='_Admin__TextBox_Link' target="_blank" href='#' id='${ID_UniqueWithName}'></a>
                `
        ContainerNode_Edit.innerHTML += Node_Edit

        if (State == 'Default') {
            _ContainerNode_.innerHTML += _Node_
            let DictController = {}
            DictController['TypeController'] = 'Link'
            DictController['TextBoxID'] = String(`${ID_UniqueWithName}`)
            ListCreatedController.push(JSON.stringify(DictController))
        }
        BackValueToInput()
    }
}


function DeleteContainer_Added(Element, Type) {
    let TextBoxID = GetInput(Element).getAttribute('TextBoxID')
    let TextBox = document.querySelector(`#${TextBoxID}`)
    if (TextBox != null) {

        let CounterIndexList = 0
        let NewListCreateController = []
        ListCreatedController.filter(function (Dict) {
            console.log(Dict)
            try{
                Dict = JSON.parse(Dict)
            }catch (e) {
            }
            if (Dict['TextBoxID'] != TextBoxID) {
                NewListCreateController.push(Dict)
            }
            CounterIndexList++
        })
        ListCreatedController = NewListCreateController
        // SendAjax('/AdminPanel/Obj/RemoveController', {'TextBox': TextBoxID, 'Type': Type}, 'POST')
        Element.remove()
        TextBox.remove()
    } else {
        ShowNotificationMessage('مشکلی پیش امده است', 'Error', 5000, 3)
    }
}

let Text_Selected_For_Edit = null
let Element_Selected_For_Edit = null
let StartIndex_Selected_For_Edit = null
let EndIndex_Selected_For_Edit = null

function CreateLinkSelect(This, Parent) {

    let State = This.getAttribute('State')
    let AddressLink = Parent.querySelector('input').value
    if (AddressLink != ' ' && AddressLink != '') {
        let TextBox = document.querySelector(`#${Element_Selected_For_Edit.getAttribute('TextBoxID')}`)
        let Node_Link = `
                    <a href="http://${AddressLink}" target="_blank">${Text_Selected_For_Edit}</a>
                `
        if (TextBox != null) {
            TextBox.innerHTML = TextBox.innerHTML.ReplaceWithIndex(StartIndex_Selected_For_Edit, EndIndex_Selected_For_Edit, Node_Link)
            Parent.querySelector('input').value = ''
        } else {
            ShowNotificationMessage('متن انتخاب شده برای ایجاد لینک صحیح نیست', 'Warning', 5000, 3)
        }
    } else {
        ShowNotificationMessage('لطفا ادرس لینک خود را به درستی وارد نمایید', 'Warning', 5000, 3)
    }
}

function GetSelectionText() {
    let Text = "";
    let Element = document.activeElement;
    let ElementName = Element.tagName.toLowerCase()
    let StartIndexText = Element.selectionStart
    let EndIndexText = Element.selectionEnd
    let DictResult = {}
    if ((ElementName == "textarea") || (ElementName == "input") &&
        (typeof Element.selectionStart == "number")
    ) {
        Text = Element.value.slice(Element.selectionStart, Element.selectionEnd);
    } else if (window.getSelection) {
        Text = window.getSelection().toString();
    }

    function StateMenuAddLink(ElementName, Text) {
        let Btn_Add_Aside_Link = document.getElementById('Btn_Add_Aside_Link')
        if (ElementName == 'textarea' || ElementName == 'input') {
            if (Text != ' ' && Text != '' && Text != null) {

                if (Element.type != 'color') {
                    Btn_Add_Aside_Link.setAttribute('State', 'SelectText')
                    Text_Selected_For_Edit = Text
                    Element_Selected_For_Edit = Element
                    StartIndex_Selected_For_Edit = StartIndexText
                    EndIndex_Selected_For_Edit = EndIndexText
                }

            } else {
                Btn_Add_Aside_Link.setAttribute('State', 'NotSelect')
            }
        } else {
            Btn_Add_Aside_Link.setAttribute('State', 'NotSelect')
        }
    }

    StateMenuAddLink(ElementName, Text)

    DictResult['Text'] = Text
    DictResult['StartIndex'] = StartIndexText
    DictResult['EndIndex'] = EndIndexText
    DictResult['ElementName'] = ElementName
    DictResult['Element'] = Element
    return DictResult;
}


document.onmouseup = document.onkeyup = document.onselectionchange = function () {
    GetSelectionText()
};

let TimerOnController
let TimerRemoveOnController

function OnControllerAndFocus(This) {
    try {
        clearTimeout(TimerOnController)
    } catch (e) {
    }
    SetForAllControllerZIndex_4()
    This.style.zIndex = '10'

}


function SetForAllControllerZIndex_4() {
    let AllController = document.querySelectorAll('[Controller]')
    for (let i of AllController) {
        i.style.zIndex = '4'
    }
}

let CounterPositionOnElement = false

function BackValueToInput() {
    let AllController = GetControllers()
    for (let Controller of AllController) {
        let TypeController = Controller.getAttribute('ControllerText')
        if (TypeController != null) {
            let Input = GetInput(Controller)
            let InputColor = Controller.querySelector('[InputColor]')
            let InputFontSize = Controller.querySelector('[InputFontSize]')
            let InputBold = Controller.querySelector('[InputBold]')
            let InputItalic = Controller.querySelector('[InputItalic]')
            let Mt = Controller.querySelector('[Mt]')
            let Mb = Controller.querySelector('[Mb]')
            let Mr = Controller.querySelector('[Mr]')
            let Ml = Controller.querySelector('[Ml]')


            Mt.value = Mt.getAttribute('ValueSeted')
            Mb.value = Mb.getAttribute('ValueSeted')
            Mr.value = Mr.getAttribute('ValueSeted')
            Ml.value = Ml.getAttribute('ValueSeted')


            let FontSize = Input.getAttribute('FontSize')
            let Color = Input.getAttribute('ColorText')
            let Text = Input.getAttribute('Text')
            if (Text != null) {
                Input.value = Text
            }
            if (Color != null) {
                InputColor.value = Color
            }
            if (FontSize != null) {
                InputFontSize.value = FontSize
            }

            if (Input.getAttribute('Bold') == 'true') {
                Input.classList.add('_Admin__BoldText')
                InputBold.classList.add('_Admin__ActiveItemTools')
                InputBold.setAttribute('State', 'true')
                Input.setAttribute('Bold', 'true')
            }
            if (Input.getAttribute('Italic') == 'true') {
                Input.classList.add('_Admin__ItalicText')
                InputItalic.classList.add('_Admin__ActiveItemTools')
                InputItalic.setAttribute('State', 'true')
                Input.setAttribute('Italic', 'true')
            }
            if (CounterPositionOnElement) {
                PositionOnController(Controller.querySelector('.MenuItemTools input[PositionAbsolute]'), Controller, 'GetInfo')
                TextAlignController(Controller.querySelector('.MenuItemTools input[TextAlign]'), Controller, 'GetInfo')
                ControllerCenter(Controller.querySelector('.MenuItemTools input[TextAlign]'), Controller, 'GetInfo')
            }
            CounterPositionOnElement = true
        }
    }

}

function BackValueToImage() {
    let AllImage = document.querySelectorAll('[Image]')
    for (let d of AllImage) {
        d.src = d.getAttribute('Src_Past')
    }
}


function SetTextInput(This) {
    let TextBoxID = This.getAttribute('TextBoxID')
    let TextBox = document.querySelector(`#${TextBoxID}`)
    TextBox.innerHTML = This.value
    This.setAttribute('Text', This.value)
}

function SetAddressLink(This, Element) {
    let InputText = GetInput(Element)
    let TextBoxID = InputText.getAttribute('TextBoxID')
    let TextBox = document.querySelector(`#${TextBoxID}`)
    let AddressLink = `http://${Element.querySelector('[InputLink]').value}`
    TextBox.setAttribute('ToHref', AddressLink)
    This.setAttribute('ToHref', AddressLink)
    if (TextBox.tagName == 'DIV') {
        TextBox.setAttribute('onclick', 'GoToUrlElement(this)')
    } else {
        TextBox.href = AddressLink
    }
}

function ItalicText(This, Element) {
    let State = This.getAttribute('State')
    let Input = GetInput(Element)
    let TextBoxID = Input.getAttribute('TextBoxID')
    let TextBox = document.querySelector(`#${TextBoxID}`)
    if (State == 'false') {
        TextBox.classList.add('_Admin__ItalicText')
        Input.classList.add('_Admin__ItalicText')
        This.classList.add('_Admin__ActiveItemTools')
        This.setAttribute('State', 'true')
        Input.setAttribute('Italic', 'true')
    } else {
        TextBox.classList.remove('_Admin__ItalicText')
        Input.classList.remove('_Admin__ItalicText')
        This.classList.remove('_Admin__ActiveItemTools')
        This.setAttribute('State', 'false')
        Input.setAttribute('Italic', 'false')
    }
}

function BoldText(This, Element) {
    let State = This.getAttribute('State')
    let Input = GetInput(Element)
    let TextBoxID = Input.getAttribute('TextBoxID')
    let TextBox = document.querySelector(`#${TextBoxID}`)
    if (State == 'false') {
        TextBox.classList.add('_Admin__BoldText')
        Input.classList.add('_Admin__BoldText')
        This.classList.add('_Admin__ActiveItemTools')
        This.setAttribute('State', 'true')
        Input.setAttribute('Bold', 'true')
    } else {
        TextBox.classList.remove('_Admin__BoldText')
        Input.classList.remove('_Admin__BoldText')
        This.classList.remove('_Admin__ActiveItemTools')
        This.setAttribute('State', 'false')
        Input.setAttribute('Bold', 'false')
    }

}

function FontSize(This, Element) {
    let FontSize = This.value;
    let Input = GetInput(Element)
    let TextBoxID = Input.getAttribute('TextBoxID')
    let TextBox = document.querySelector(`#${TextBoxID}`)
    TextBox.style.fontSize = FontSize + 'px'
    Input.style.fontSize = FontSize + 'px'
    Input.setAttribute('FontSize', FontSize)
}


function ColorText(This, Element) {
    let Input = GetInput(Element)
    let TextBoxID = Input.getAttribute('TextBoxID')
    let TextBox = document.querySelector(`#${TextBoxID}`)
    if (Text_Selected_For_Edit != null) {
        if (EndIndex_Selected_For_Edit++ == Text_Selected_For_Edit.length) {
            TextBox.style.color = This.value
            Input.setAttribute('ColorText', This.value)

            // Input.style.color = This.value
        } else {
            let Node = `<p style='color:${This.value}'>${Text_Selected_For_Edit}</p>`
            let NewTextBox
            NewTextBox = document.createElement('div')
            if (TextBox.tagName == 'A') {
                let Href = TextBox.getAttribute('ToHref')
                NewTextBox.setAttribute('onclick', 'GoToUrlElement(this)')
            }
            NewTextBox.innerHTML = TextBox.innerHTML
            NewTextBox.className = TextBox.className
            NewTextBox.id = TextBoxID
            let StyleTextBox = TextBox.getAttribute('style')
            if (StyleTextBox != null) {
                NewTextBox.setAttribute('style', StyleTextBox)
            }
            NewTextBox.innerHTML = TextBox.innerText.ReplaceWithIndex(StartIndex_Selected_For_Edit, EndIndex_Selected_For_Edit, Node)
            Container_Base_Node.replaceChild(NewTextBox, TextBox)
            TextBox.remove()
        }
    } else {
        TextBox.style.color = This.value
    }
}


function ControllerCenter(This, Element, TypeCall = 'Event') {
    let State = This.getAttribute('IsChecked')
    let TextBox = document.getElementById(GetInput(Element).getAttribute('TextBoxID'))
    if (TypeCall == 'Event') {
        if (State == 'false') {
            Element.classList.add('d-block')
            Element.classList.add('m-auto')
            TextBox.classList.add('d-block')
            TextBox.classList.add('m-auto')
            This.setAttribute('IsChecked', 'true')
            This.setAttribute('checked', '')
        }
        if (State == 'true') {
            Element.classList.remove('d-block')
            Element.classList.remove('m-auto')
            TextBox.classList.remove('d-block')
            TextBox.classList.remove('m-auto')
            This.setAttribute('IsChecked', 'false')
        }
    }
    if (TypeCall == 'GetInfo') {
        if (State == 'false') {
            This.removeAttribute('checked')
        }
        if (State == 'true') {
            This.setAttribute('checked', '')
        }
    }
}

function TextAlignController(This, Element, TypeCall = 'Event') {
    let State = This.getAttribute('IsChecked')
    let TextBox = document.getElementById(GetInput(Element).getAttribute('TextBoxID'))
    if (TypeCall == 'Event') {
        if (State == 'false') {
            Element.classList.add('text-center')
            TextBox.classList.add('text-center')
            This.setAttribute('IsChecked', 'true')
            This.setAttribute('checked', '')
        }
        if (State == 'true') {
            Element.classList.remove('text-center')
            TextBox.classList.remove('text-center')
            This.setAttribute('IsChecked', 'false')
        }
    }
    if (TypeCall == 'GetInfo') {
        if (State == 'false') {
            This.removeAttribute('checked')
        }
        if (State == 'true') {
            This.setAttribute('checked', '')
        }
    }
}


function MarginOnController(This, Element, Type) {
    let TextBoxID = document.getElementById(GetInput(Element).getAttribute('TextBoxID'))

    This.setAttribute('ValueSeted', This.value)
    if (Type == 'Top') {
        Element.style.marginTop = This.value + 'px'
        TextBoxID.style.marginTop = This.value + 'px'
    }
    if (Type == 'Bottom') {
        Element.style.marginBottom = This.value + 'px'
        TextBoxID.style.marginBottom = This.value + 'px'
    }
    if (Type == 'Right') {
        Element.style.marginRight = (This.value / 6) + '%'
        TextBoxID.style.marginRight = (This.value / 6) + '%'
    }
    if (Type == 'Left') {
        Element.style.marginLeft = (This.value / 6) + '%'
        TextBoxID.style.marginLeft = (This.value / 6) + '%'
    }
}

function SetInStyle(Class, Attribute, Value, Element) {
    let Style = document.getElementById('StyleNode')
    let StrStyle = String(Style.innerHTML)
    let StylePast = Element.getAttribute('StylePastSet')
    let StyleCreate = `.${Class} { ${Attribute}:${Value}; } `
    if (StylePast == null || StylePast == undefined) {
        Style.innerHTML += StyleCreate
    } else {
        Style.innerHTML = StrStyle.replace(StylePast, StyleCreate)
    }
    Element.setAttribute('StylePastSet', StyleCreate)
}

function SetLocation(This, ContainerBtn, Element, Type) {
    try {
        clearInterval(TimerSetLocation)
    } catch (e) {
    }
    let TimerSetLocation
    TimerSetLocation = setInterval(
        function () {
            let StateActiveBtn = Element.querySelector('button:active')
            if (StateActiveBtn != null) {
                MovingContainer(This, ContainerBtn, Element, Type)
            } else {
                clearInterval(TimerSetLocation)
            }
        }, 5)
}

function MovingContainer(This, ContainerBtn, Element, Type) {
    let ContainerNode = document.getElementById('_Admin__ContainerNode')
    let Input = Element.querySelector('[InputText]')
    let TextBoxID = Input.getAttribute('TextBoxID')
    let TextBox = document.querySelector(`#${TextBoxID}`)
    let HeightContainer = parseInt(ContainerNode.offsetHeight)
    let WidthContainer = parseInt(ContainerNode.offsetWidth)
    let WidthContainerAdded = parseInt(Element.offsetWidth)
    let HeightContainerAdded = parseInt(Element.offsetHeight)
    let RightPast = parseInt(ContainerBtn.getAttribute('Right'))
    let TopPast = parseInt(ContainerBtn.getAttribute('Top'))
    let ValueTop = TopPast
    let ValueRight = RightPast
    if (Type == 'Top') {
        if (TopPast > -43) {
            ValueTop--
        }
    }
    if (Type == 'Bottom') {
        if (TopPast <= HeightContainer) {
            ValueTop++
        }
    }
    if (Type == 'Left') {
        if (RightPast <= WidthContainer) {
            ValueRight++
        }
    }
    if (Type == 'Right') {
        if (RightPast > 0) {
            ValueRight--
        }
    }
    ContainerBtn.setAttribute('Right', ValueRight)
    ContainerBtn.setAttribute('Top', ValueTop)
    Element.style.right = ValueRight + 'px'
    Element.style.top = ValueTop + 'px'
    TextBox.style.top = ValueTop + 'px'
    TextBox.style.right = ValueRight + 'px'

}

let _ContextDataEdit_ = {
    "Titles": [],
    "Texts": [],
    "Images": [],
    "Links": [],
    "ListCreated": ListCreatedController
}
let AccessSubmitObject = true
let _Admin__Container__Node = document.getElementById('_Admin__Container__Node')

function SubmitObject() {
    if (AccessSubmitObject) {
        FormSubmitObject.querySelector('[name=NodeEdit]').value = AddNodeEditTo_Form()
        FormSubmitObject.querySelector('[name=NodeText]').value = _Admin__Container__Node.innerHTML
        BackValueToImage()
        FormSubmitObject.submit()
    }
}

// function AddImagesTo_Form() {
//     let CounterImage = 0
//     FormSubmitObject = document.getElementById('FormSubmitObject')
//     let AllInputsImage = document.querySelectorAll('[InputImage]')
//     for (let Image of AllInputsImage) {
//         CounterImage++
//         // let TextBoxID = Image.getAttribute('TextBoxID')
//         // let TextBoxIDForImage = document.createElement('input')
//         // TextBoxIDForImage.name = `Image_TextBoxID_${CounterImage}`
//         // TextBoxIDForImage.value = TextBoxID
//         Image.name = `Image_${CounterImage}`
//         // FormSubmitObject.appendChild(TextBoxIDForImage)
//         FormSubmitObject.appendChild(Image)
//     }
// }


function AddNodeEditTo_Form() {

    let ControllersText = document.querySelectorAll('[ControllerText]')
    for (let Controller of ControllersText) {
        let InputText = Controller.querySelector('[InputText]')
        let TextBoxID = InputText.getAttribute('TextBoxID')
        let Text = document.getElementById(TextBoxID).innerHTML
        let Color = GetAttributeButNone(InputText, 'ColorText')
        let FontSize = GetAttributeButNone(InputText, 'FontSize', 'Text')
        let Bold = GetAttributeButNone(InputText, 'Bold', 'Bool')
        let Italic = GetAttributeButNone(InputText, 'Italic', 'Bool')
        let Mt = Controller.querySelector('[Mt]').getAttribute('valueseted')
        let Mb = Controller.querySelector('[Mb]').getAttribute('valueseted')
        let Mr = Controller.querySelector('[Mr]').getAttribute('valueseted')
        let Ml = Controller.querySelector('[Ml]').getAttribute('valueseted')
        let Center = Controller.querySelector('[CenterController]').getAttribute('IsChecked')
        let TextAlign = Controller.querySelector('[TextAlign]').getAttribute('IsChecked')
        let Position = Controller.querySelector('[PositionAbsolute]').getAttribute('IsChecked')
        let Right = Controller.querySelector('[ContainerBtnMove]').getAttribute('Right')
        let Top = Controller.querySelector('[ContainerBtnMove]').getAttribute('Top')
        let Width = Controller.getAttribute('WidthSeted')
        Width = Width == null ? 'Auto' : Width
        let Height = Controller.getAttribute('HeightSeted')
        Height = Height == null ? 'Auto' : Height
        let ObjectController = {
            "Text": Text,
            "TextBoxID": TextBoxID,
            "Color": Color,
            "FontSize": FontSize,
            "Bold": Bold,
            "Italic": Italic,
            "Mt": Mt,
            "Mb": Mb,
            "Mr": Mr,
            "Ml": Ml,
            "Center": Center,
            "TextAlign": TextAlign,
            "Position": Position,
            "Right": Right,
            "Top": Top,
            "Width": Width,
            "Height": Height,
        }
        let TypeController = Controller.getAttribute('TypeController')
        if (TypeController == 'Link') {
            ObjectController['Href'] = Controller.querySelector('[InputLink]').value
        }
        if (TypeController == 'Title') {
            _ContextDataEdit_.Titles.push(ObjectController)
        } else if (TypeController == 'Text') {
            _ContextDataEdit_.Texts.push(ObjectController)
        } else if (TypeController == 'Link') {
            _ContextDataEdit_.Links.push(ObjectController)
        }
    }


    let ControllerImage = document.querySelectorAll('[ControllerImage]')
    for (let Controller of ControllerImage) {
        let InputText = Controller.querySelector('[InputText]')
        let TextBoxID = InputText.getAttribute('TextBoxID')
        let Mt = Controller.querySelector('[Mt]').getAttribute('valueseted')
        let Mb = Controller.querySelector('[Mb]').getAttribute('valueseted')
        let Mr = Controller.querySelector('[Mr]').getAttribute('valueseted')
        let Ml = Controller.querySelector('[Ml]').getAttribute('valueseted')
        let Center = Controller.querySelector('[CenterController]').getAttribute('IsChecked')
        let TextAlign = Controller.querySelector('[TextAlign]').getAttribute('IsChecked')
        let Position = Controller.querySelector('[PositionAbsolute]').getAttribute('IsChecked')
        let Right = Controller.querySelector('[ContainerBtnMove]').getAttribute('Right')
        let Top = Controller.querySelector('[ContainerBtnMove]').getAttribute('Top')
        let Width = Controller.getAttribute('WidthSeted')
        Width = Width == null ? 'Auto' : Width
        let Height = Controller.getAttribute('HeightSeted')
        Height = Height == null ? 'Auto' : Height
        let ObjectController = {
            "TextBoxID": TextBoxID,
            "Mt": Mt,
            "Mb": Mb,
            "Mr": Mr,
            "Ml": Ml,
            "Center": Center,
            "TextAlign": TextAlign,
            "Position": Position,
            "Right": Right,
            "Top": Top,
            "Width": Width,
            "Height": Height,
        }
        _ContextDataEdit_.Images.push(ObjectController)
    }
    _ContextDataEdit_['ListCreated'] = ListCreatedController
    return JSON.stringify(_ContextDataEdit_)
}


function GetAttributeButNone(Element, Attribute, Type = 'Text') {
    let Q = Element.getAttribute(Attribute)
    Q = (Q != null) ? Q : (Type == 'Bool') ? false : (Type == 'Number') ? 0 : (Type == 'Text') ? 'None' : 'None'
    return Q
}


function SetSrcImages() {
    let ImagesData = {
        'Images': []
    }
    let AllImages = document.querySelector('#_Admin__Container__Node').querySelectorAll('img')
    for (let Image of AllImages) {
        let TextBoxID = Image.getAttribute('id')
        ImagesData.Images.push(TextBoxID)
    }
    SendAjax('/p/Article/GetImage', ImagesData, 'POST', SetSrcImagesGeted)

    function SetSrcImagesGeted(response) {
        if (response.Status == '200') {
            let ListSrc = response.Images
            let CounterLoopImage = 0
            for (let Image of AllImages) {
                Image.setAttribute('src', ListSrc[CounterLoopImage])
                Image.setAttribute('Src_Past', ListSrc[CounterLoopImage])
                CounterLoopImage++
            }
        }
    }

}


function ReverceBoolean(Bool) {
    let Res
    if (Bool == true || Bool == 'true') {
        Res = false
    } else {
        Res = true
    }
    return Res
}


function _CreateConrollerGeted__(TypeController, TextBoxID, Text, Href, Image, Bold, Italic, FontSize, Mt, Mb, Mr, Ml, Color, Center, TextAlign, Position, Top, Right, Width, Height) {

    if (Bold == 'True') {
        Bold = true
    } else if (Bold == 'False') {
        Bold = false
    }
    if (Italic == 'True') {
        Italic = true
    } else if (Italic == 'False') {
        Italic = false
    }
    if (Center == 'True') {
        Center = true
    } else if (Center == 'False') {
        Center = false
    }
    if (TextAlign == 'True') {
        TextAlign = true
    } else if (TextAlign == 'False') {
        TextAlign = false
    }
    if (Position == 'True') {
        Position = true
    } else if (Position == 'False') {
        Position = false
    }
    if (FontSize == 'None') {
        FontSize = 21
    }

    if (TypeController == 'Title') {
        CreateTitle(TextBoxID, Text, Bold, Italic, FontSize, Mt, Mb, Mr, Ml, Color, Center, TextAlign, Position, Top, Right, Width, Height, 'Geted')
        LoadDataController(TextBoxID, 'Title')
        let DictController = {}
        DictController['TypeController'] = 'Title'
        DictController['TextBoxID'] = String(`${TextBoxID}`)
        ListCreatedController.push(JSON.stringify(DictController))
    }
    if (TypeController == 'Text') {
        CreateText(TextBoxID, Text, Bold, Italic, FontSize, Mt, Mb, Mr, Ml, Color, Center, TextAlign, Position, Top, Right, Width, Height, 'Geted')
        LoadDataController(TextBoxID, 'Text')
        let DictController = {}
        DictController['TypeController'] = 'Text'
        DictController['TextBoxID'] = String(`${TextBoxID}`)
        ListCreatedController.push(JSON.stringify(DictController))
    }
    if (TypeController == 'Image') {
        CreateImage(TextBoxID, Image, Mt, Mb, Mr, Ml, Center, TextAlign, Position, Top, Right, Width, Height, 'Geted')
        // LoadDataController(TextBoxID, 'Image')
        let DictController = {}
        DictController['TypeController'] = 'Image'
        DictController['TextBoxID'] = String(`${TextBoxID}`)
        ListCreatedController.push(JSON.stringify(DictController))
    }
    if (TypeController == 'Link') {
        CreateLink('NotSelect', TextBoxID, Text, Href, Bold, Italic, FontSize, Mt, Mb, Mr, Ml, Color, Center, TextAlign, Position, Top, Right, Width, Height, 'Geted')
        LoadDataController(TextBoxID, 'Link')
        let DictController = {}
        DictController['TypeController'] = 'Link'
        DictController['TextBoxID'] = String(`${TextBoxID}`)
        ListCreatedController.push(JSON.stringify(DictController))
    }
}
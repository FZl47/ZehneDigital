
CodeDec = {
    'a':'g2',
    'A':'G1',
    'b':'tt',
    'B':'En',
    'c':'xx',
    'C':'q3',
    'd':'kw',
    'D':'aa',
    'e':'rr',
    'E':'ft',
    'f':'1l',
    'F':'b8',
    'g':'po',
    'G':'pi',
    'h':'ty',
    'H':'uu',
    'i':'sd',
    'I':'0l',
    'j':'8j',
    'k':'2v',
    'K':'Zs',
    'l':'TW',
    'L':'9M',
    'm':'4G',
    'M':'U2',
    'n':'qe',
    'N':'sg',
    'o':'SF',
    'O':'IU',
    'p':'YY',
    'P':'RC',
    'q':'vv',
    'Q':'Q4',
    'r':'f2',
    'R':'8H',
    's':'FN',
    'S':'sA',
    't':'4w',
    'T':'t6',
    'u':'1k',
    'U':'1D',
    'v':'T3',
    'V':'S8',
    'w':'oq',
    'W':'px',
    'x':'gf',
    'X':'C3',
    'y':'2B',
    'Y':'LP',
    'z':'Kv',
    'Z':'Ba',
    '1':'jj',
    '2':'i1',
    '3':'ve',
    '4':'fr',
    '5':'0b',
    '6':'2m',
    '7':'em',
    '8':'re',
    '9':'Rt',
    '0':'Bv',
    '@':'PV',
    '-':'4S',
    '_':'J2'
}


def Decode(Password):
    PasswordDecoded = ''
    for C in Password:
        PasswordDecoded += CodeDec[C]
    return PasswordDecoded


def UnDecode(PasswordDecode):
    PasswordUnDecoded = ''
    try:
        if PasswordDecode == None or PasswordDecode == '': return None
        for Index in range(len(PasswordDecode)):
            if Index % 2 == 0:
                SplitPasswordDecode = f'{PasswordDecode[Index]}{PasswordDecode[Index + 1]}'
                for Key, Val in CodeDec.items():
                    if Val == SplitPasswordDecode:
                        PasswordUnDecoded += Key
    except:
        PasswordDecode = ''

    return PasswordUnDecoded





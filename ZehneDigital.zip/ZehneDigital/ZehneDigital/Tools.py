import datetime
import pytz
import time

TimeIranZone = pytz.timezone('Asia/Tehran')
TimeIranObject = datetime.datetime.now(TimeIranZone)
TimeIran = TimeIranObject.now()


def GetTimeIran():
    TimeIranZone = pytz.timezone('Asia/Tehran')
    TimeIranObject = datetime.datetime.now(TimeIranZone)
    TimeIran = TimeIranObject.now()
    return TimeIran


def GetDifferenceTime(Time):
    TimeIranZone = pytz.timezone('Asia/Tehran')
    TimeIranObject = datetime.datetime.now(TimeIranZone)
    TimeIran = TimeIranObject.now()
    DifferenceTime = datetime.datetime(TimeIran.year, TimeIran.month, TimeIran.day, TimeIran.hour,
                                       TimeIran.minute) - datetime.datetime(Time.year, Time.month, Time.day, Time.hour,
                                                                            Time.minute)
    DifferenceTimeSecond = DifferenceTime.seconds
    Second = DifferenceTimeSecond % 60
    Minute = DifferenceTimeSecond // 60 % 60
    Hour = DifferenceTimeSecond // 3600
    Day = DifferenceTime.days
    Str = ''
    if Minute > 0:
        Str = f'{Minute} دقیقه پیش'
    else:
        Str = f'لحظاتی پیش'

    if Hour > 0:
        Str = f'{Hour} ساعت پیش'

    if Day > 0:
        Str = f'{Day}  روز پیش'

    return Str



def KeyWordsSite():
    ListKeyWord = [
        'ذهن دیجیتال'


            ]
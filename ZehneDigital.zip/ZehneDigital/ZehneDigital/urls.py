
from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.urls import path,include
from django.conf import settings
from .views import Home , SendTicketAdmin

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', Home),
    path('p/',include('Article.urls','Article')),
    path('Err/',include('Errors.urls','Errors')),
    path('AdminPanel/',include('Admin.urls','Admin')),
    path('SendTicketAdmin',SendTicketAdmin)
]
handler404 = 'Errors.views.View_404_Exception'
handler403 = 'Errors.views.View_403_Exception'

if settings.DEBUG:
    urlpatterns = urlpatterns + static(settings.STATIC_URL,document_root=settings.STATIC_ROOT)
    urlpatterns = urlpatterns + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
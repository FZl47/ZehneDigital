import json
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_exempt
from Article.models import *
from Admin.models import Support_Ticket , ZehneDigitalInfo
def Home(request):
    Context = {}
    Articles = Article.objects.order_by('-DateCreate')
    if Articles.first() is not None:
        Articles = Articles[:30]
    ArticlesMostView = Article.objects.order_by('-Views')
    if ArticlesMostView.first() is not None:
        ArticlesMostView = ArticlesMostView[:20]
    ArticlesMostLikes = Article.objects.order_by('-Likes')
    if ArticlesMostLikes.first() is not None:
        ArticlesMostLikes = ArticlesMostLikes[:20]
    Context['Articles'] = Articles
    Context['ArticlesMostView'] = ArticlesMostView
    Context['ArticlesMostLikes'] = ArticlesMostLikes
    Context['AllCategories'] = CategoriesArticle.objects.all()
    Context['ZehneDigitalInfo'] = ZehneDigitalInfo.objects.first()

    return render(request,'Home.html',Context)


@csrf_exempt
def SendTicketAdmin(request):
    if request.is_ajax():
        Context = {}
        Data = json.loads(request.body)
        Title = False
        Name = False
        Email = False
        Text = False
        try:
            Title = Data['Title']
            Name = Data['Name']
            Email = Data['Email']
            Text = Data['Text']
        except:
            pass
        if Title and Name and Email and Text:
            Support_Ticket.objects.create(Title=Title,Text=Text,Email=Email,Name=Name,DateSubmit=TimeIran)
            Context['Status'] = '200'
        else:
            Context['Status'] = '500'

        return JsonResponse(Context)
    return redirect('/Err/403')